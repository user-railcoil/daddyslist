# DADDY'S LIST: MASTER PLAN AND HANDOFF

Read this whole file, then read `HANDOFF.md` (the older project handoff). This file adds everything that has happened since: what is built, what is not, and the full ordered plan, including the games.

**UPDATE October 10, 2026: the sync was rebuilt (merge instead of overwrite). See `HANDOFF.md` section 12 and Section 11 below. Rules 11 and the sync items in this file were updated.**

Written October 8, 2026. Based on reading the code only. **Nothing here has been run or visually checked by the AI that wrote it.** Ask the owner for a screenshot after every visual change.

---

## 0. HOW TO USE THIS FILE

- Section 1: rules for working with the owner (read first)
- Section 2: project facts (hosting, files, storage keys, code map)
- Section 3: what is already built (needs comments in code, see Step S0)
- Section 4: the owner's original requests, cleaned up, so nothing is lost
- Section 5: the ordered build plan, in batches, each item labeled
- Section 6: the games plan (20 Questions is first)
- Section 7: open questions and the "forgot some" list
- Section 8: progress checklist
- Section 9: announcing changes (update popup and NEW badge with ripple)
- Section 10: LAYOUT PLAN (where every new feature lives; non-scrolling screens; hub; video games; Point Bomb replacement)
- Section 11: sync status
- **Section 13: REDESIGN FROM THE GROUND UP (requests 59 to 61: Minecraft theme rethink, full redesign with layouts, minimalism especially on desktop; planning only)**
- **Section 12: NEW REQUEST ROUND, October 13, 2026 (requests 37 to 58, plain-English, nothing built yet, with questions to ask)**

---

## 1. RULES FOR WORKING WITH THE OWNER

1. The owner uses **only a phone**. No computer, no terminal. He updates the site through github.com in Safari.
2. He is non-technical and dislikes jargon. Use plain language. **One step at a time.** Keep messages short.
3. He has a limited AI budget. Do not waste turns. **Group changes into one upload per batch.**
4. Deliver **complete finished files** to upload, not patches. Tell him the exact GitHub URL for each file (see `HANDOFF.md` section 3).
5. Keep visual changes conservative and consistent. He has been burned by designs that looked incoherent.
6. He wants **uniform text sizes**. Never shrink one item to fit. Make boxes bigger instead.
7. After editing: run `node --check` on every `<script>` body and every `.mjs` file. Edit `index.html` with careful targeted string replacement (`assert count == 1`). Never rewrite the original minified app wholesale.
8. Keep every existing localStorage key name. The sync depends on the `daddys-list*` prefix.
9. Keep the **sync shim as the first script** and the **chat widget as the last script**.
10. After every deploy, tell him to wait about 2 minutes and reload twice on every device (old cached copies are a recurring problem).
11. **Sync problems are the owner's #1 pain** (October 10, 2026). Laptop sync problems (data wiped on a big window, nothing pushing to her laptop) were reported earlier; the one-device wipe on refresh does not reproduce any more, but two devices overwriting each other did and was fixed with a merge on October 10, 2026. If sync problems come back, read `HANDOFF.md` section 12 first (suspect an old cached page before anything else), and keep the sync shim as the first script.
12. **Announce every major change on the site.** After a major change, ship a one-time "what's new" popup AND a NEW badge with the ripple animation where the feature lives, in the same upload. Full how-to in Section 9 and `HANDOFF.md` section 10. Skip for tiny fixes.
13. **Non-scrolling screens.** The owner likes designs that do not scroll. Every new screen must fit one phone screen with big tap targets. If there is more content, page it (the `rail-nav` arrows pattern) or group it, or split it into more buttons. Before adding a new button, use a tap target that does nothing today (Section 10.2).

---

## 2. PROJECT FACTS

### Hosting
- Live site: https://daddyslist.netlify.app (Netlify project `daddieslist`)
- Source: GitHub repo `user-railcoil/daddieslist`, branch `main`. Every commit auto-deploys in about 1 to 2 minutes.
- Server data lives in Netlify Blobs, store name `daddys-list`, keys `state` and `chat`.
- Optional env var `SYNC_TOKEN` (not currently set). If set, both functions require header `x-sync-token`.

### Files
```
index.html                    whole front end (current version is about 345 KB)
netlify.toml                  publish="." functions="netlify/functions"
package.json                  type: module, dependency @netlify/blobs ^8.1.0
netlify/functions/state.mjs   /api/state  (sync of localStorage; merges per key since Oct 10, 2026)
netlify/functions/chat.mjs    /api/chat   (chat, alerts, edit/delete/clear)
HANDOFF.md                    older handoff (does not cover Rewards, Movies, brightness, points adjust)
```
The `index.html` inside the zip the owner sent is an OLD copy (232 KB). The current one is the separate 345 KB upload. Always confirm which is current.

### Backend behavior (observed)
- `state.mjs`: GET returns `{data, version}`. PUT now takes `{patch:{key:{b,v}}}` and **merges** it into the newest server copy (inner items of JSON-object keys merged one by one; see `HANDOFF.md` 12.2). Returns `{version, data}`. The old whole-snapshot PUT `{data}` is still accepted for old cached pages. Reads use strong consistency. It does not record IP or browser.
- `chat.mjs`: keeps up to 200 messages. Handles new message, `ack`, `clear`, `del`, `edit`. Alerts only honored from `daddy`.
- Roles are not real authentication. `?daddy` in the URL sets `__dl_role = daddy` on that device.

### Storage keys (localStorage)
Synced to the server (anything starting `daddys-list`, except the three device-specific ones):
- `daddys-list-state`, `daddys-list-live`, `daddys-list-history`
- `daddys-list-points-adj` (running points total adjustment, **read with `parseInt`**)
- `daddys-list-rewards` (reward items, claimed list, owed rewards)
- `daddys-list-rewards-start` (day Rewards launched, used by the 3-miss rule)
- `daddys-list-movies`, `daddys-list-movies-ep`

Not synced (device-specific): `daddys-list-bright`, `daddys-list-nightshift`, `daddys-list-state-v1-backup`, `__dl_token`, `__dl_role`, `__dl_dirty`, `dl-rewards-welcome-v1`, `dl-rewards-opened-v1`, `__dl_chat_seen`.

### Code map of `index.html` (approximate line numbers in the 345 KB version)
| Lines | What |
|---|---|
| 1 to 55 | Sync shim v2 (first script; merge-based, Oct 10, 2026) |
| 38 | Writes a `vw_0 = 150` value into `daddys-list-state` once |
| 41 to 150 | Main CSS (original app plus theme variables) |
| 154 to 267 | `GRID_DATA`: all schedule cells. **Cell ids are permanent. Never reuse or renumber.** |
| 269 to 286 | Theme toggle, **long-press on the theme box opens brightness** (`THEME_HOLD_MS`, pointer events) |
| 305 to 520 | Snapshot and history capture |
| 846 to 1027 | Brightness boost and night-shift UI (6 levels each) |
| 1042 to 1250 | Daddy's points-adjust popup |
| 1316 to 1590 | Movie list, ratings, +3 "movie night", Point Bomb |
| 1600 to 1700 | Chat and alert widget (last app script) |
| 1715 to 1730 | `perf-patch` style block |
| 1732 to 1975 | Rewards: CSS, HTML, logic |
| 1980 to 2160 | Warp/ripple effects (Rewards "NEW" badge) |
| 2185 on | One-time "everything's fixed" notice |

---

## 3. WHAT IS ALREADY BUILT

### Status: built
- Sync via `/api/state` with an optional passcode. Checks the server every 4 seconds and **reloads only when the server version changed**. **Since October 10, 2026 saves are merged on the server, so two devices no longer wipe each other's ticks** (tested in a simulation only; the owner has not confirmed on real devices yet).
- Chat and full-screen alerts between the two of them.
- Rewards: reward list, claiming (spends points), "owed" rewards with a late bonus, and the 3-miss penalty (every 3 missed tasks costs 1 point).
- Daddy's points-adjust popup.
- Movie list with ratings, +3 points for a movie night, and Point Bomb.
- Light and dark toggle, brightness, and night shift (long-press the theme box).
- Basic points pop animation and haptics (`navigator.vibrate`).
- History view.
- `?daddy` and `?her` roles.

### Status: partly built
- **Completion timestamps:** a code comment says timestamps are saved, but I found no per-task completion time being stored. The only time formatting function is for chat.
- **Performance:** a low-power flag (`window.__LOW`) and a `perf-patch` style exist. There are no warnings or levels.
- **Daddy accidental edits:** there is a role check (`isAdmin()`), but no lock or confirm for edits.
- **Red times:** time cells have red and green pulse classes (`pulse-r1`, `pulse-g1`, and similar). I could not confirm they mean "deadline."
- **Reload:** the page still does a full `location.reload()` to show another device's changes (only when idle and only when the server has something new). Two devices editing before a reload no longer lose data (merge, Oct 10, 2026).

### Status: not built
Everything in Section 5 that is not listed above, including all games.

---

## 4. THE OWNER'S ORIGINAL REQUESTS (CLEANED UP)

Every request, so nothing gets lost. Each maps to a plan item in Section 5.

1. Once a reward is used, it can't be used again. Later there is a way to bring back old rewards (or all of them).
2. Uploading a video earns 2 points.
3. On desktop, holding the mouse down to open brightness and night-mode intensity does nothing.
4. Generate a text output of all updated movie ratings at any time.
5. Timestamp of when a task is done.
6. Bug reporting for points.
7. Red times mean the task must be completed by that time.
8. Fix tasks that keep clearing.
9. See which browser the site is being accessed from.
10. Stop daddy from changing tasks accidentally. Changes must be purposeful.
11. Chrome was not saving her points. (Laptop sync: two-device overwrite fixed Oct 10, 2026, awaiting the owner's real-device test. See rule 11 and Section 11.)
12. Keep the IP address.
13. Everything disappears when she manually refreshes, in Chrome and Edge, on her laptop. It works when the window is phone-sized. (Does not reproduce in headless Chrome at 1280 x 800 and when resizing up to 1920 wide as of Oct 10, 2026; refresh and window resizing keep and sync the data. Awaiting the owner's confirmation on her real laptop.)
14. Themes and color changes. Each theme has its own feel and a light mode.
15. The site should only reload when a change is made somewhere.
16. Unique, detailed week summaries at the end of the week, based on how she did, using AI.
17. Show all possible points for the day instead of 0/12.
18. Fewer ripples, for more stability.
19. Periodic double-points periods.
20. Redesign.
21. Random timed requests that give points if completed in 20 minutes (the owner supplies the text and the points).
22. A satisfying animation, sound, and/or message whenever she gets a point or completes a task.
23. More satisfying the more points she gets. The more points she has, the more opportunities to get points. It is exponential.
24. Every 3 food items eaten earns 1 point.
25. Three levels of performance mode if the site runs poorly. Notify each time with an option to revert. First notice after 30 seconds of poor performance, second after 1 minute, third after 2 minutes, only if it is still poor at each level. Each notice lists the features it is turning off.
26. An extra 0.5 points for pooping more than once, with a new message each time.
27. She likes the big boxes and ease of use but wants a better time schedule. Times are not always accurate, and not everything should be 3 hours apart.
28. Beat daddy in a game to win rewards or points. Rewards are not always points. Keep it interesting.
29. **20 Questions (like the iOS GamePigeon game) is the first game to build.**
30. Change the app icon to reflect how the app looks and feels.
31. **The top title should sometimes comically change to "master's list" instead of "daddy's list."**
32. The owner says there were more requests he forgot. See Section 7.
33. **Rewards for finishing video games WITH daddy** (example: Halo 5). Needs its own place. See Section 10.4.
34. **Move the movie list and Point Bomb into the Total Points hub**, and replace the Point Bomb cell with something else. See Section 10.5.
35. **Non-scrolling designs.** Break things into different buttons or places to tap instead of long scrolling screens. Give a use to the boxes that do nothing when tapped before adding new buttons. See Section 10.1 and 10.2.
36. **"Daddy becomes a sub" reward** for 1 or 2 hours with limits. See Section 9b.
59 to 61. **Added October 13, 2026: see Section 13** (redesign from the ground up, minimal, desktop first).
37 to 58. **Added October 13, 2026: see Section 12** (Eat screen bug, desktop resize, admin confirm, movie sorting, food penalty, secret tasks, remove a task, theme voting, claim screen, poop animation, new rewards, punishments, aftercare, lottery, Learn something, No AI coding reward).

---

## 5. ORDERED BUILD PLAN

Each batch is **one upload** and **one screenshot check**. Item ids like `B1.2` are used for progress tracking.

### S0: Comment all existing code (do first, no behavior changes)
- Add a short plain-English comment above every feature listed under "built" and "partly built" in Section 3: what it does, which localStorage keys it reads or writes, and what depends on it.
- Update `HANDOFF.md` to cover Rewards, Movies/Point Bomb, brightness, points adjust, and this file.
- Do not change any logic. Run `node --check` on every script. Deliver complete files.
- Done when: every block in the code map in Section 2 has a comment and the site behaves exactly as before.

### Batch H: layout homes (`index.html` only; do right after S0, before Batch 1)
Build the empty places first, so every later feature just drops into a home. No new game or point logic yet. Details in Section 10.
- **BH.1 Hub.** Total Points opens a non-scrolling hub of big tiles (Section 10.3). Move the existing Rewards screen into the Rewards tile and make it non-scrolling (it currently scrolls: `#rw-box` has `overflow-y:auto`).
- **BH.2 Banner.** A slide-down banner over the nutrition bar for temporary things (Section 10.7). It must not resize the grid.
- **BH.3 Daddy tools tile.** Move the existing admin bits (add reward, points adjust, mark delivered, replay NEW badge) into one Daddy tools screen, admin only.
- **BH.4 Today screen.** Tapping DAILY POINTS opens a simple Today screen (Section 10.2). Fill it in as Batch 3 lands.
- **BH.5 Food screen.** Tapping the nutrition bar opens a simple Food screen (Section 10.2).
- **BH.6 Movies tile.** Move the Motion Comics/Pictures list into the hub (Section 10.5). Keep the +3 card and ratings exactly as they are.
- **BH.7 Replace the Point Bomb cells** (Section 10.5) once the owner picks what goes there.
- **BH.8 Chat bubble.** Move it so it never covers the Sleep box.
- Each tile gets a NEW badge when it first appears (Section 9). One page ripple at a time.
- Done when: the 12-box screen looks the same except the replaced cell, every old feature still works from its new home, and phone plus laptop screenshots match what the owner expects.

### Batch 1: quick wins (`index.html` only)
- **B1.1 Backup button.** A "download backup" button that exports all `daddys-list*` keys as a JSON file. Protects data during all later work.
- **B1.2 Desktop brightness hold (request 3).** The handler is in the theme-box `pointerdown` code (about line 269). Likely cause: the label's own click or text selection cancels it. Test in desktop Chrome. Consider handling `contextmenu`, `user-select: none`, and `touch-action`.
- **B1.3 Daddy edit lock (request 10).** Editing is locked by default. A tap-and-hold or confirm unlocks it, and it relocks after about 2 minutes. Store the lock in a non-synced key.
- **B1.4 One-time rewards (request 1).** Claiming marks the item `used: true` with a time and hides it. Add a buyable "Bring back a used reward" item and a daddy "restore one / restore all" button. Claimed rewards are already pushed to `claimed[]` in `daddys-list-rewards`, so extend that.
- **B1.5 Fewer ripples (request 18).** Default the ripple and warp effects off, with a toggle. Related code is around lines 1980 to 2160.
- **B1.6 Movie ratings text export (request 4).** One button reads `daddys-list-movies` and offers copy, share, and download as .txt.

### Batch 2: games (new `games.mjs` plus new overlay in `index.html`)
Full plan in Section 6. **20 Questions is first.**
- **B2.1 Game framework.** The server function, the game overlay, the polling, and the prize hookup.
- **B2.2 20 Questions.**
- **B2.3 Prize wheel and prize table.**
- Later games (tic-tac-toe, Connect 4, trivia or memory) come after the rest of the plan, or sooner if the owner wants.
- **B2.4 Video games with daddy** (request 33, Section 10.4). A library like the movie list, with points for finishing. Needs the owner's answers in Section 7 first.

### Batch 3: point rules (`index.html`)
- **B3.1 Put every point source in one table in the code.** All later point features depend on this.
- **B3.2 Half points (request 26).** `getAdj()` uses `parseInt`. Change every points read to `parseFloat` and display halves cleanly.
- **B3.3 Show max possible points (request 17).** Sum all possible sources for the day, including bonuses.
- **B3.4 Extra poop (+0.5, request 26).** The Poop cell (`dayplan`) becomes a counter. The first check counts normally, each extra gives +0.5 with a message from a rotating pool.
- **B3.5 Food (request 24).** Count food items logged through the Eat picker (`eat1-eat`, `eat2-eat`). Award `floor(items / 3)`. First find where food items are stored.
- **B3.6 Completion timestamps (request 5).** Store a time per cell id when checked in a new synced key such as `daddys-list-done-times`, reset daily, copied into history, and shown on the cell.
- **B3.7 Red time means deadline (request 7).** Add an optional `due` field per task. The time turns red when overdue. Confirm what the existing pulse classes do first.
- **B3.8 Double-points windows (request 19).** A synced `daddys-list-boosts` record with start, end, and multiplier. Show a banner. Daddy sets them manually first. Random windows can come later.
- **B3.9 Points bug-report button (request 6).** A button that sends a snapshot of the points breakdown. Stored in Batch 4.

### Batch 4: server upgrades (`index.html`, `state.mjs`, new `report.mjs`)
- **B4.1 Log browser and IP (requests 9 and 12).** In Netlify functions, read the user-agent header and the client IP (from the function context or the `x-nf-client-connection-ip` header). Keep a short "last seen" list per device in Blobs, viewable only in the admin view. Cap the list size.
- **B4.2 Safer sync (requests 8 and 15). FIRST HALF DONE Oct 10, 2026:** the server now merges per key and per inner item (three-way merge against the last synced copy) instead of replacing the whole snapshot, and the page reloads only when the server has something this device lacks. **Still to do:** apply other devices' changes in place instead of `location.reload()`; per-key timestamps for same-item conflicts (today: later `savedAt` or day wins, otherwise the saving device); an optional "sync fixed" popup. Details in Section 11.
- **B4.3 Store bug reports** from B3.9 and show them to daddy.

### Batch 5: feel (`index.html`)
- **B5.1 `celebrate(points)` function (request 22).** Tiers: small tick and toast, medium, big burst and sound, biggest for milestones. Sounds are synthesized with WebAudio (no audio files). Respect `prefers-reduced-motion` and performance mode.
- **B5.2 Exponential opportunities (request 23).** Daily point milestones unlock bonus chances (a spin, a bonus task, a double window). Define the tiers in one table.
- **B5.4 Comic title swap (request 31).** The header title is two spans inside `.dayplan-label`: `<span class="glitch-wrapper dpl-line" data-text="daddy's"><span class="label-text">daddy's</span></span>` and the same for `list`. Occasionally swap the first word to `master's` (change BOTH the `data-text` attribute and the inner `.label-text`), play the existing glitch effect, then swap back after a short time. Possible triggers: a random chance on page load or on a timer (for example about 1 in 8 loads, shown for 20 to 60 seconds), a big point burst, a double-points window, or a daddy button to force it. Leave the header classes and its tap and hold reset behavior alone. Do not change the browser tab title or the home-screen name (`<title>` and `apple-mobile-web-app-title`). Per-device only, no syncing needed. Respect `prefers-reduced-motion` and performance mode (B5.3).
- **B5.3 3-level performance mode (request 25).** Measure frame times with `requestAnimationFrame`. Poor performance for 30 seconds gives notice 1, 1 minute gives notice 2, 2 minutes gives notice 3, each only if still poor. Each notice lists exactly what it turns off (ripples, warp, 3D zen animation, grain and screen-door overlays, theme transitions) and has a revert button. Build on `window.__LOW` and the `perf-patch`.

### Batch 6: schedule (`index.html`)
- **B6.1 Flexible times (request 27).** Each row or task gets its own editable time, stored in a new synced key. Cell ids stay permanent. Deadlines from B3.7 plug in here. This is the riskiest change to the grid, so keep it conservative and ask for screenshots.

### Batch 7: more server features (`chat.mjs` plus new functions)
- **B7.1 Random timed requests (request 21).** A new message type with custom text, points, and a 20-minute expiry. She taps done, daddy confirms, and points are awarded. Reuse the alert system.
- **B7.2 Video earns 2 points (request 2).** Netlify functions cap request bodies at about 6 MB, so real video upload will not work. Start with "she marks it sent, daddy confirms, +2." Real upload needs outside storage later.
- **B7.3 AI weekly summary (request 16).** A scheduled function runs each Sunday night, reads that week's history, and calls the Claude API. The owner adds one secret API key in Netlify's environment settings. The result is stored in Blobs and shown as a "Week in review" card. It should mention specific tasks, streaks, and misses so each week is unique.

### Batch 8: look (do last, so work is not redone)
- **B8.1 Themes (request 14).** Each theme is a set of CSS variables in `<style id="dl-theme">` with its own light mode and a picker. Do NOT override `--bar-thickness`, `--time-bg`, or `--header-height` globally.
- **B8.2 Redesign (request 20).** Conservative. Screenshot after every change. The layout homes (Batch H) come BEFORE this, so redesign only restyles them.
- **B8.4 Look and feel tile.** Theme picker, performance mode, ripple toggle, brightness shortcut, all in one non-scrolling screen (Section 10.3).
- **B8.3 New app icon (request 30).** Generate new PNGs from the final look. Replace the favicon and `apple-touch-icon` in the head.

---

## 6. GAMES PLAN

### Shared framework (B2.1)
- New function `netlify/functions/games.mjs` at `/api/games`, storing games in the same Blobs store under key `games`.
- Turn-based and **asynchronous**. The front end polls every 3 seconds while a game is open, like chat. They can play at different times.
- A game record: `{id, type, players, turn, state, status, winner, prize, prizeApplied, createdAt}`.
- **Prizes are applied exactly once.** The record has a `prizeApplied` flag. The first device that sees a finished game with a prize applies it (points through the existing points-adjust key, or an owed reward) and sets the flag through the server.
- **Secrets must stay on the server.** Never send hidden information (like the 20 Questions secret word) to the other player until the game ends.
- Roles are not real authentication, but it is a private two-person app, so trusting the `from` field is acceptable (same as chat).
- A "Games" button, a game picker, and a game overlay. Keep the existing style (big boxes, uniform text, current palette).

### 20 Questions (B2.2): FIRST GAME
Based on the iOS GamePigeon game. **I could not verify GamePigeon's exact rules.** These are assumed. Confirm with the owner before building (see Section 7).

**Rules (assumed):**
1. One player is the **Thinker**, the other is the **Asker**. Roles swap each round.
2. The Thinker secretly picks something (free text, optionally with a category such as animal, food, place, object, person).
3. The Asker has **20 yes/no questions**. The Thinker answers each with **Yes**, **No**, **Sometimes**, or **Don't know**.
4. The Asker can make a guess at any time. A guess **does not use a question** unless the owner wants it to (open question). The Thinker taps **Correct** or **Wrong**, so no string matching is needed.
5. Asker wins by guessing correctly within 20 questions. Thinker wins if the 20 questions run out with no correct guess (the Asker gets one final guess).

**Game state:** `{thinker, asker, category, secret (server only), questions: [{q, a, at}], guesses: [{g, ok, at}], status}`.

**Screens:**
- Thinker: pick category, type the secret, then a waiting screen. When a question arrives: question text and four answer buttons.
- Asker: question counter (for example `7 / 20`), history of questions and answers, a text box to ask, a "Make a guess" button.
- End screen: reveals the secret, shows the result, and applies the prize.

**Prizes:**
- If she beats daddy: a prize from the prize table (below).
- If daddy beats her: a small consolation or nothing (the owner decides, see Section 7).
- Limit how many rounds can award prizes per day.

**Risks:** the secret must never reach the Asker's device early. Keep question and answer text rendered with `textContent` (no HTML injection), as chat does.

### Prize table and wheel (B2.3)
- Stored in one place, editable by daddy.
- Prize types: points, a free pick of tonight's movie, a "daddy owes you" item (reuses the owed-rewards system), a double-points window (reuses B3.8), a mystery reward.
- Rewards are **not always points.** The wheel randomizes among the table.

### Later games (order is flexible)
1. **Tic-tac-toe** (smallest turn-based game)
2. **Connect 4**
3. **Trivia or memory game**
4. Any others from the owner's "forgot some" list (Section 7)

Each game adds one `type` to `games.mjs` and one screen. The framework and prize system are shared.

---

## 7. OPEN QUESTIONS AND THE "FORGOT SOME" LIST

Ask the owner these before building the related item:

1. **20 Questions rules:** are the assumed rules in Section 6 right? Does a wrong guess cost a question? Does the Thinker pick from a fixed word list or type any word? Does daddy also get consolation prizes?
2. **Prize limits:** how many prize-earning games per day?
3. **Video (B7.2):** is "she marks it sent, daddy confirms" good enough, or does he need real upload?
4. **Food counting (B3.5):** how does he want food items counted (per Eat entry, per item picked)?
5. **Deadlines (B3.7):** which tasks have deadlines, and who sets them?
6. **Weekly AI summary (B7.3):** is he willing to add an API key in Netlify's environment settings?
7. **Master's list swap (B5.4):** how often should it appear, and what should trigger it (random, special moments, or a daddy button)?
8. **Point Bomb cells (BH.7):** what replaces them? Recommended default: a daily "Together time" box (a movie, a game, or a walk with daddy) worth the usual 1 point, which links the Movies and Video games tiles.
9. **Video games (B2.4):** does she play WITH daddy only, or solo too? Who confirms a finish (daddy, like movies)? Points per game: one flat number, or by difficulty (for example Normal, Heroic, Legendary)? Points for single missions or only a full finish? Are rewards sometimes not points (request 28)? Which games go on the list first (Halo 5 and what else)?
10. **Movies list is long (86 items):** page it by collection or era with arrows, or is scrolling allowed for this one list?
11. **Food screen (BH.5):** one tap target for the whole nutrition bar, or should each of the five stats open its own detail?
12. **Look and feel:** should she be able to change theme and performance herself, or only daddy?
13. **More requests:** the owner said there were more requests he forgot. **Add them here when he remembers:**
   - Added Oct 13, 2026: see Section 12 (requests 37 to 58) and its **ASK** questions.

---

## 8. PROGRESS CHECKLIST

- [ ] S0 Comments in code and `HANDOFF.md` updated
- [ ] B1.1 Backup button
- [ ] B1.2 Desktop brightness hold
- [ ] B1.3 Daddy edit lock
- [ ] B1.4 One-time rewards and restore
- [ ] B1.7 "Daddy is your sub" reward (Section 9b)
- [ ] BH.1 Hub (Total Points opens big tiles, non-scrolling)
- [ ] BH.2 Banner over the nutrition bar
- [ ] BH.3 Daddy tools tile
- [ ] BH.4 Today screen (Daily Points tap)
- [ ] BH.5 Food screen (nutrition bar tap)
- [ ] BH.6 Movies tile
- [ ] BH.7 Replace Point Bomb cells
- [ ] BH.8 Chat bubble off the Sleep box
- [ ] B2.4 Video games with daddy
- [ ] B8.4 Look and feel tile
- [ ] B1.5 Fewer ripples
- [ ] B1.6 Movie ratings text export
- [ ] B2.1 Game framework
- [ ] B2.2 20 Questions
- [ ] B2.3 Prize wheel and prize table
- [ ] B3.1 Points table
- [ ] B3.2 Half points
- [ ] B3.3 Show max possible points
- [ ] B3.4 Extra poop +0.5
- [ ] B3.5 Food (3 items = 1 point)
- [ ] B3.6 Completion timestamps
- [ ] B3.7 Red time = deadline
- [ ] B3.8 Double-points windows
- [ ] B3.9 Points bug-report button
- [ ] B4.1 Log browser and IP
- [~] B4.2 Safer sync (merge done Oct 10, 2026; in-place updates not done)
- [ ] B4.3 Store bug reports
- [ ] B5.1 Celebration system
- [ ] B5.2 Exponential opportunities
- [ ] B5.3 3-level performance mode
- [ ] B5.4 Comic "master's list" title swap
- [ ] B6.1 Flexible schedule times
- [ ] B7.1 Random timed requests
- [ ] B7.2 Video +2 points
- [ ] B7.3 AI weekly summary
- [ ] Later games: tic-tac-toe, Connect 4, trivia or memory
- [ ] B8.1 Themes
- [ ] B8.2 Redesign
- [ ] B8.3 New app icon
- [x] NEW badge and ripple locked to one beat clock (October 8, 2026)
- [~] R37 Eat screen refresh and not saving (fix attempted Oct 13, 2026 in the sync shim; passes the simulated test; waiting for the owner to try it on his phone and her laptop)
- [ ] R38 Desktop resizable windows
- [ ] R39 Admin confirm before highlight or refresh
- [ ] R40 Movies sort by rating and DC or Marvel
- [ ] R41 Lose 1 point for fewer than 3 foods a day, with warning
- [ ] R42 Secret tasks after the others
- [ ] R43 Remove a task for days (points and/or other)
- [ ] R44 Theme voting, max 3 themes
- [ ] R45 Reward claim screen
- [ ] R46 Surprise poop animation
- [ ] R47 600 points = $100 display
- [ ] R48 to R51 and R58 New rewards (Reverse, Double, Baby wendango, Mommy?, No AI coding 3 days)
- [ ] R52 Movie night price 6 points
- [x] R62 Reward: $100 for 600 points (added to `index.html` Oct 13, 2026; payment questions still open)
- [ ] R53 Locked rewards and achievements
- [ ] R54 Punishments
- [ ] R55 Aftercare 0 to 100 points
- [ ] R56 Point lottery
- [ ] R57 Learn something module
- [ ] Generalize the NEW badge so it can mark any feature, not just Total Points (Section 9)

---

## 9. ANNOUNCING CHANGES (UPDATE POPUP AND NEW BADGE WITH RIPPLE)

Standing rule from the owner: after major changes, push the little update to the site, and add the NEW badges with the ripple animation where they fit, so new features get noticed.

For every major change, include in the same upload:
1. **A one-time update popup.** Copy `#fx-w` or `#rw-w`. Per-device flag named `dl-<topic>-v1` (never starts with `daddys-list`, so it does not sync), a `?replay` URL switch, waits if another popup is open, 2 to 4 short plain points.
2. **A NEW badge with the ripple** on the box or button where the feature lives. It goes away for good the first time that thing is opened. Only one badge at a time gets the page-wide ripple; the rest get the badge and ring only.
3. A line in this file's checklist, and a note in `HANDOFF.md` section 9 describing the feature.

State of the code: the badge exists only on TOTAL POINTS today (REWARDS script, `[S0L]`). Generalizing it to any element is the open item in Section 8. Timing is on one shared clock (beat 3750 ms, peak at 750 ms, big beat and page ripple every 7500 ms); read `HANDOFF.md` section 10 before touching any badge or ripple number.

Tension with request 18 (fewer ripples, B1.5): the NEW badge ripple is wanted. When B1.5 and B5.3 add a performance toggle, let it switch the page-wide water effect off while keeping the badge and its ring.

### 9b. Reward idea: "Daddy becomes a sub" (owner request, not built)

A reward she can claim where daddy takes the sub role for a set time: 1 hour, 2 hours, and so on. Build it as ordinary reward items in `daddys-list-rewards` (so it uses the existing two-tap claim), with these limits so it stays safe, fun and fair:
- **Tiers and cost:** for example 1 hour = 150 points, 2 hours = 300 points (owner picks the numbers). Longer tiers cost proportionally more.
- **Daily/weekly cap:** at most one claim per week and no more than 2 hours per claim (owner can raise it). Show "available again on <date>" on the button.
- **Scheduling:** it is claimed first, then a time is agreed; it does not start the moment she taps. Daddy sees it in an "Owed" style card with a start time and a countdown (reuse the owed-rewards card).
- **Hard limits and safe word:** a short, agreed list of off-limits things written by both of them, and a safe word that ends it immediately with no questions and no penalty. Show the limits on the card.
- **Stop button:** either person can end it early; unused time is NOT refunded unless daddy ends it (then refund the unused part).
- **Daddy's say:** he can decline or move it once per claim for a real reason (work, sleep, health); a declined claim is refunded in full.
- **Not during:** sleep hours, medication times, or while another timed reward is running.
- Keep wording on the card and popup plain and non-explicit; the details live between the two of them.
When built, announce it with the update popup and a NEW badge (Section 9).

---

## 10. LAYOUT PLAN (discussed October 8, 2026; nothing here is built yet)

Why: the phone screen is already full (4-box header, nutrition bar, 12 big task boxes) and the notes add about 15 features with no home. Decision: **leave the 12-box screen alone** (the owner likes the big boxes; flexible times are the riskiest item) and give every new feature a home elsewhere. I rendered the current screen at phone (390 x 844) and laptop (1280 x 800) sizes in headless Chromium to check; the assistant can now screenshot before delivering. Fonts and network are missing in that sandbox, so ask the owner for a real phone screenshot too.

### 10.1 Principles
1. The main 12-box screen stays the same, except the Point Bomb cells (10.5).
2. **No scrolling screens.** Each screen fits one phone screen. More content means pages with arrows, groups, or more buttons.
3. **Use tap targets that do nothing today first** (10.2), then add buttons.
4. **One door for new things:** Total Points opens a hub of big tiles (10.3).
5. Temporary things (double points, timed requests, countdowns) use a banner, not a new screen (10.7).
6. Every new tile or screen gets a NEW badge and an update popup (Section 9). Only one page-wide ripple at a time.
7. Uniform text sizes. Never shrink one item to fit; make the box bigger or split the screen.

### 10.2 Tap targets that do nothing today (checked in the code on October 8, 2026)
Nothing is attached to **DAILY POINTS** (`#pts-today`) or to the five nutrition stats (**FIB, ADDED SUG, PRO, CAL, SOD**, class `nutri-stat`). Already in use, so leave alone: TOTAL POINTS (opens Rewards; handler `hook()` in the points-adjust script calls `window.openRewards`), WEIGHT (number wheel), the red dot box (theme; hold for brightness), the title (reset behavior), time cells (hold sets the day start hour).
- **DAILY POINTS opens a "Today" screen:** big number out of the most she can earn today (B3.3), whether a double-points window is active, extra poop +0.5, food progress (for example 2 of 3 items toward the next point), the milestone ladder for bonus chances (B5.2), the last few completion times (B3.6; the full list is in History), and a **Report a problem** button (B3.9). Fits on one screen.
- **The nutrition bar opens a "Food today" screen:** the five numbers large, today's logged foods, and the 3-items-equals-1-point progress (B3.5). Start with one tap target for the whole bar. Later it can be split so each stat opens its own detail (open question 11).

### 10.3 The hub (Total Points)
Tapping TOTAL POINTS opens a hub styled like the main grid: big bordered tiles, 2 columns, no scrolling. Each tile opens its own non-scrolling screen. With 7 tiles (her view) the last tile spans both columns; with 8 (daddy) it is a clean 2 x 4.
| Tile | What it holds | Status |
|---|---|---|
| REWARDS | Pick a reward (paged, about 4 per page), Owed countdown, Claimed. Subtitle on the tile shows the Owed countdown. | exists, must be made non-scrolling |
| MOVIES | Motion Comics / Motion Pictures list, ratings, +3 new movie with daddy, text export button (B1.6) | exists (moves here) |
| VIDEO GAMES | Games to play with daddy, points for finishing (10.4) | new |
| PLAY | Beat daddy: 20 Questions first, prize wheel and prize table, later tic-tac-toe, Connect 4, trivia | new |
| EARN MORE | Ways to earn extra right now: active double-points window, random timed request, "I sent my video" (+2), new movie with daddy (+3) | new |
| WEEK AND HISTORY | AI Week in review card (B7.3) and the History view | partly exists |
| LOOK AND FEEL | Theme picker, performance mode and notices, ripple toggle, brightness shortcut | new |
| DADDY TOOLS | Admin only (below) | partly exists |
**Daddy tools** (admin only): edit lock and unlock, backup (B1.1), restore used rewards (B1.4), add reward, points adjust, mark delivered, double-points windows, random timed requests, confirm videos, game finishes and requests, bug reports inbox, last-seen devices (B4.1), movie export, force the "master's list" title, replay NEW badge. Group it in pages of big buttons so it does not scroll.

### 10.4 Video games with daddy (request 33)
A library modeled on the movie list (`daddys-list-movies` is the pattern). Proposed key `daddys-list-vgames` (synced), items like `{id, name, platform, status ('to play' | 'playing' | 'beat'), pts, doneAt, confirmed}`. Same look as Movies: status counts across the top (to play / playing / beat), tap a game for a big card. Finishing asks "did you finish this game?" and daddy confirms (same idea as the movie popup), then the points are added through the points table (B3.1). Possible extras, pending the owner's answers (Section 7, question 9): points by difficulty, points per play session with daddy, a one-time bonus for the first finish, and non-point rewards. Halo 5 is the first example.

### 10.5 Movies and Point Bomb
Move the movie list into the MOVIES tile. Today it lives in the tea overlay (`.tea-overlay`, "Motion Comics") and Point Bomb shows the same list full screen (`pbSync()`, class `pb-full`, `mcTitle()`). **Point Bomb is three cells, not one:** ids `weigh-self`, `groom2-groom`, `groom3-groom`, all with class `is-tea is-pbomb` and lines `['Point','Bomb']` (the 6pm right box in the current layout; the others appear in other layouts). `weigh-self` also drives the weigh-self number picker (groom2 overlay), so check that before changing it. Cell ids are permanent; change only the label and behavior, and make sure old history entries still read correctly. Recommended replacement: a daily **Together time** box (movie, game, or a walk with daddy), 1 point like any task. Wait for the owner's choice (open question 8). Remove the full-screen behavior only after the Movies tile works.

### 10.6 Where everything else lives
| Feature | Home |
|---|---|
| Max possible points (B3.3), completion times (B3.6) | Today screen (Daily Points tap); times also in History |
| Poop counter and +0.5 (B3.4) | The Poop box itself (becomes a counter), message pool on the toast |
| Food 3 items = 1 point (B3.5) | Food screen, and the Eat picker |
| Red time = deadline (B3.7) | The time cell itself turns red; daddy sets deadlines in Daddy tools |
| Double-points windows (B3.8) | Banner; set in Daddy tools; listed in Earn more |
| Random timed requests (B7.1) | Banner with countdown; also the alert system; set in Daddy tools |
| Video +2 (B7.2) | Earn more ("I sent it"), confirmed in Daddy tools |
| Daddy becomes a sub (Section 9b) | A reward item plus an Owed-style card in Rewards |
| Bug report (B3.9) | Button on the Today screen; inbox in Daddy tools (B4.3) |
| Edit lock (B1.3), backup (B1.1), restore (B1.4) | Daddy tools |
| Celebrations (B5.1) and bonus ladder (B5.2) | Animation on the spot; ladder on the Today screen |
| Master's list title swap (B5.4) | The header title itself; force button in Daddy tools |
| Performance mode (B5.3), ripples toggle (B1.5), themes (B8.1) | Look and feel tile; performance notices as a banner |
| Flexible times (B6.1) | Time cells; daddy edits them in a Daddy tools page or by hold. Keep this last and conservative. |
| Update popups and NEW badges | Section 9 |

### 10.7 Banner
A strip that slides down over the nutrition bar for a limited time (so the grid never changes size). It shows one thing at a time with a priority order: timed request countdown, double-points window, Owed countdown, performance notice, update note. Tapping it opens the matching screen. It disappears when nothing is active.

### 10.8 Laptop
On wide screens the right-hand rail already holds overlay cards (workout, movies). Plan: hub screens open in that rail area instead of a bottom sheet. Check with a laptop-size screenshot at the first build, and keep the existing resize behavior.

### 10.9 Risks
- The Rewards screen, the points-adjust popup, the movie overlay and the chat panel are separate pieces built at different times. Moving them into the hub must not break the sync keys or the `window.__dlChatOpen` guard that stops reloads while a panel is open.
- Do not override `--bar-thickness`, `--time-bg`, `--header-height`.
- Keep the sync shim as the first script and the chat widget as the last.

---

## 11. SYNC STATUS (added October 10, 2026)

The owner's biggest problem. Full write-up in `HANDOFF.md` section 12. Short version:

- **Cause found:** every save replaced the whole server copy, so a device that was behind (typically her laptop: a hidden tab open for hours, mouse use not counted as activity) wiped the other device's newer ticks the moment it saved one tick. Two taps in the same second also lost one. Reproduced in a two-device simulation.
- **Fixed:** the server merges (`state.mjs`), the page sends only what changed and remembers its last synced copy (`__dl_base`), failed saves retry, mouse and focus count, and a forgotten open panel stops blocking updates after 2 minutes idle.
- **Earlier laptop bug (data gone on refresh at a wide window):** documented above as requests 11 and 13 and rule 11. Not reproduced in the October 10 tests (refresh, resize across the phone/laptop breakpoint, up to 1920 wide). Still needs the owner's real-laptop confirmation.
- **Not verified:** real Netlify, her real laptop, Safari. The Blobs `consistency: "strong"` option is unchecked outside Netlify. Old cached copies of the page still use the old whole-snapshot save.
- **Owner's test:** `HANDOFF.md` 12.4. **Deploy:** 12.7.
- **Next in this area (B4.2 second half):** update the page in place instead of reloading; optional one-time popup; maybe a small "synced / saving / offline" dot so she can see sync is working.

---

## 12. NEW REQUEST ROUND (owner, October 13, 2026): NOT BUILT YET

**Rule for this round: NO CODE has been written for any of this.** It is the owner's list, cleaned up so it is easy to read. Do not change `index.html` until the owner says which item to build first. Numbers continue from Section 4 (requests 37 to 62). Every item is status: NOT BUILT. Anything marked **ASK** is unclear and must be asked, one short question at a time (see 12.9).

### 12.1 Quick overview (one line each)

| # | Item | Type |
|---|------|------|
| 37 | Eat screen keeps refreshing and nothing saves | BUG |
| 38 | Desktop mode: resizable windows | New feature |
| 39 | Admin mode: confirm before highlighting or refreshing | Safety |
| 40 | Movies: sort by rating and by DC or Marvel | New feature |
| 41 | Lose 1 point if fewer than 3 food items logged in a day | Point rule |
| 42 | Secret new tasks appear after she finishes the others | New feature |
| 43 | Remove a task for a day or a few days (costs points and/or something else) | New feature |
| 44 | Vote on themes, max 3 themes at once | New feature |
| 45 | Beautiful claim screen when a reward is claimed (Minecraft-theme quality) | Look and feel |
| 46 | Surprise poop animation, alternating at random with the normal card | Look and feel |
| 47 | 600 points = $100 | Fact / display |
| 48 | Reward: Reverse reward (50 pts) | Reward |
| 49 | Reward: Double reward (60 pts) | Reward |
| 50 | Reward: Baby wendango (10 pts) | Reward |
| 51 | Reward: Mommy? (69 pts) | Reward |
| 52 | Reward: Movie night price changes to 6 pts | Reward edit |
| 53 | Some rewards locked or hidden until achievements are earned | Rewards system |
| 54 | Punishments (reasons) | New system |
| 55 | Aftercare reward after a punishment: random 0 to 100 points | New system |
| 56 | Point lottery: pay 10 points to play, win 0 to 100 | Game |
| 57 | Learn something: daddy-chosen lesson module, +10 points | New feature |
| 58 | Reward: No AI coding for 3 days (3 pts) | Reward |
| 62 | Reward: $100 for 600 points | Reward |

### 12.2 Fix first: the Eat screen (request 37)

- **What happens now (owner's words, cleaned up):** typing food in the Eat section makes the site keep updating and refreshing, and none of it gets saved or logged.
- **Why it matters most:** it blocks request 41 (3 food items a day) and the earlier food-point rule (request 24, every 3 food items = 1 point).
- **Suspects to check (read the code, do not guess):** the sync (`HANDOFF.md` sections 12 to 14) re-rendering the page or reloading while an input box is focused; the "update on change" logic (request 15). Compare with the rule that a forgotten open panel blocks updates for 2 minutes. Test on phone and laptop width.
- **FIX ATTEMPTED (Oct 13, 2026; passes the simulated test but NOT yet confirmed on real devices), the owner's idea, kept simple:** the sync check (`poll()` in the first script) reloaded the page whenever the other device had saved something and she paused typing for 2 seconds. That wiped the typed text and restarted the screen. Now, while the Eat screen is open (grid class `has-eat1`), the page does NOT reload for updates; her own saves still go out as normal. When she closes Eat, the next check catches up (reload when idle). Safety: if Eat sits open and untouched for 10 minutes, the hold ends. Search `EAT TYPING FIX` in `index.html`. Test: `sync-tests/run_eat.py` (closed = reloads in about 3 s, open = held, closed again = catches up in about 1 s). Not tested on real Netlify, Safari or her real laptop. Other popups (`window.__dlChatOpen`) still hold updates for up to 2 minutes, as before.
- **Also done Oct 13, 2026:** the same food can be added twice (two eggs = two items), and a one-time "I tried to fix Eat" update card was added (`HANDOFF.md`).
- **Done when:** she can type a food, it stays in the box while typing, it is saved, it shows in the log, and it survives a refresh and syncs to the other device.

### 12.3 Desktop and admin behavior (requests 38 and 39)

- **38. Resizable windows in desktop mode.** The owner wants a feature that can "kind of resize the windows, but at certain clicks etc." **ASK:** does he mean drag the edge, or fixed size steps when a button is clicked (small / medium / large)? Which windows (Rewards, Movies, Eat, others)? Should it remember the size?
- **UPDATE Oct 13, 2026 (owner, later message): admin mode must stay FREE.** He wants to be able to mess with the site and send refreshes constantly in admin mode, "unless I want to" be protected. So request 39 below is NOT a forced lock. Build it as a **switch Daddy controls** (for example "Safety lock" in Daddy's tools): lock OFF = admin taps and refreshes work instantly like today, no questions; lock ON = the "Are you sure?" confirmation from 39. Default is OFF (free). Nothing in the code blocks admin today (39 was never built), so no code change was needed for this message. **ASK:** by "send refreshes" does he mean manual refreshes on his own device, or pushing a refresh to her device? Should the Eat hold (updates wait while Eat is open) apply to his device too?
- **39. Admin mode must not change things by accident.** In admin (Daddy) mode he must NOT be able to highlight or un-highlight things (tasks, cells), or cause the site to refresh, unless he confirms that is what he wants. Use a clear "Are you sure?" with Yes and Cancel. This extends request 10 ("changes must be purposeful"). **ASK:** which taps count (every task tap, or only un-highlighting)? Should auto-refresh from sync also be held until he confirms, or only manual refreshes?

### 12.4 Movies and food rules (requests 40 and 41)

- **40. Movies.** Let her (and him) arrange the movie list by **rating**, and by **DC or Marvel** (a studio or franchise filter or sort). The list has about 86 items in collections; keep the existing look and the non-scrolling plan (Section 10.5). **ASK:** are DC and Marvel tags already on the items? If not, the owner must say which items are which.
- **41. Food-logging penalty.** If she does **not log at least 3 food items in 1 day, she loses 1 point.** **She must be told clearly and ahead of time**: a short plain line on the Eat screen (for example, "Log at least 3 foods today or lose 1 point") plus a one-time update popup (Section 9). **ASK:** counted at the 1:00 am Eastern day rule (HANDOFF)? Does a day she never opens the app count? (Today, an unopened day has no card and no penalty, see `HANDOFF.md` section 16.) Does the 1 point lost show on the day card?
  - Related: request 24 (every 3 food items earns 1 point). Both rules use the same food count, so build food saving (12.2) first.

### 12.5 Tasks (requests 42 and 43)

- **42. Secret tasks.** After she finishes all of her normal tasks for the day, **new secret tasks appear** (a "new tasks waiting" surprise). Daddy supplies the tasks and points. **ASK:** how many, are they different every day, does he write them in advance, and do they count toward the daily maximum points?
- **43. Remove a task for a day or a few days.** She can take a task off her list for **1 day or several days**, paying with **points, and/or something else** (the owner has not said what; **ASK**). She can bring a removed task back, **the same way she can bring back rewards** (see request 1 and Section 5 B1.4). Rules to confirm: price per day, a limit (so she cannot remove everything), whether removed tasks count as missed (they must NOT count toward the 3-misses-in-a-row rule, see 12.8), and whether daddy can refuse.

### 12.6 Themes and screens (requests 44 to 46)

- **44. Theme voting.** (See Section 13: the redesign may change which themes exist.) The two of them **vote on themes**, and **only 3 different themes can be active at once.** **ASK:** who votes (her, daddy, both)? Does a tie or Daddy's vote win? Which themes exist now: original, Barbie (locked mystery theme), Minecraft (see `HANDOFF.md` section 15). Note: today the theme is saved per device and is NOT synced; a shared vote needs a synced key.
- **45. Reward claim screen.** When a reward is **actually claimed**, show an **amazing, beautiful full screen on the same level as the Minecraft theme screens**, with animations and the rest of the effects. (Current claim is a two-tap button, `HANDOFF.md` section 9.) Keep the look consistent with the active theme. Per the owner's old rule, show a screenshot or demo file to confirm. NEVER PUBLISH; send the .html file in chat only.
- **46. Poop animation.** When she taps poop, show a **funny poop animation instead of the usual popup**. It must be a **surprise**: **no card announcing it.** Each tap, randomly choose between **(a) the poop animation and (b) the regular card**, so they alternate unpredictably. Keep the extra 0.5 point rule for pooping more than once (request 26) working either way, and make sure the point is awarded no matter which one appears. **ASK:** roughly what odds (50/50?), and may it appear twice in a row?

### 12.7 Rewards, prices and the money rate (requests 47 to 53)

- **47. Money rate.** **600 points is worth $100.** (So 6 points = $1 and about 0.167 of a dollar per point.) **See also request 62 (the 600-point $100 reward).** **ASK:** is this just for display ("worth about $X")? Where should it show (Total Points, Rewards)? Is it real money?
- **New rewards.** Add as ordinary reward items in `daddys-list-rewards` so they use the existing two-tap claim and the owed-rewards card:

| # | Name | Cost | What it does |
|---|------|------|--------------|
| 48 | **Reverse reward** | 50 pts | Brings back an already used reward. |
| 49 | **Double reward** | 60 pts | Brings back or multiplies **2 more** of any given reward. |
| 50 | **Baby wendango** | 10 pts | Daddy shows proof that he changed her name in his phone to "baby wendango". |
| 51 | **Mommy?** | 69 pts | Daddy is a sub to her for **3 hours straight**. He must be a **complete** sub to mommy, or her points are **fully refunded.** |

  - **48 and 49 rule:** these act on rewards that were already used (request 1). Show a picker of her used rewards. **ASK for 49:** does "2 more" mean 2 extra copies of one chosen reward, and can it be used on Reverse reward or on itself?
  - **51 safety:** this is the "Daddy becomes a sub" idea (Section 9b). The owner set 3 hours and 69 points, which replaces the example numbers in 9b. Keep the rest of 9b's sensible limits (agreed limits list, safe word that ends it with no questions, start time agreed after the claim, not during sleep or medication times). Wording on cards stays plain and non-explicit.
- **52. Movie night.** Change the Movie night reward's price to **6 points (it was 50).** This is a data edit to the existing reward, not a new reward.
- **53. Locked or hidden rewards.** **Some rewards are locked or hidden** until she hits certain **achievements.** The achievements and which reward each unlocks are NOT decided. **ASK** the owner for the list. Reuse the existing mystery-lock pattern used for the Barbie theme (synced "earned" key plus optional Daddy approval, `HANDOFF.md` section 15). Show locked ones as "???" tiles.

- **58. Reward: "No AI coding for 3 days"** (added Oct 13, 2026). Cost: **3 points.** What it does: for **3 days, the owner cannot use AI to code the site.** If he codes anything in that time, he has to **hand code it completely himself** (no AI help at all). This reward is a rule on DADDY, like Mommy? (51), so it is an ordinary reward item with the usual two-tap claim.
  - **Honor system:** the owner upholds this himself. The AI is NOT told to refuse or block coding; it just helps as normal. (Owner instruction, Oct 13, 2026.)
  - **ASK:** does the 3 days start the moment she claims it or at midnight? Can it be claimed back to back, or is there a cooldown? Do 48 (Reverse reward) and 49 (Double reward) work on it? Is a refund given if he breaks it (like Mommy? is refunded if he is not a full sub)? Suggested default for him to approve: starts at claim, ends exactly 72 hours later, no stacking while active.

- **62. Reward: $100 (600 points)** (added to the notes AND to the site's rewards list, Oct 13, 2026). Cost: **600 points.** She gets **$100** (this is the money rate from request 47: 600 points = $100). Add it as an ordinary reward item in `daddys-list-rewards` with the normal two-tap claim, and it shows on the owed-rewards card so Daddy can pay it. **ASK:** is it one time only or can she claim it again (it can be brought back by Reverse reward 48 or doubled by Double reward 49)? How does Daddy pay (cash, Zelle, etc.) and does he mark it paid? Does the price ever change?

### 12.8 Punishments and aftercare (requests 54 and 55)

- **54. Punishments.** A punishment can be given for: (1) **disrespecting daddy in day-to-day life**, or (2) **doing something he decides is not okay.** Also, **missing any task 3 times in a row** makes her **susceptible to discipline.** "Susceptible" means it is **Daddy's call, not automatic.** Do not auto-apply anything. This ties to the existing 3-misses rule in the code; read how it counts missed days first (`HANDOFF.md` section 16: only saved days count). Daddy needs a simple admin place to assign, edit and mark a punishment done, and she sees it as a card. **ASK:** what are the punishments (the owner writes them)? Can she see why? Does a removed task (43) count as a miss? (Recommended: no.)
- **54b. Punishment idea: a reward with a time limit (owner, Oct 13, 2026).** Some punishments could put a **time limit on one of her rewards before it goes away**. When the time runs out, the reward **gets used as if she had bought it** (it is marked claimed in `daddys-list-rewards`, same as a normal claim, but **no points are spent or refunded**). She can still get it back with Reset, Reverse reward or Double reward. Suggested build for him to approve: Daddy picks the reward and a deadline; she sees a countdown card like the Owed card (reuse `renderOwed`); doing the thing before the deadline (or Daddy marking it done) cancels it. **ASK:** can she cancel it by paying points? Does it work on locked or Perfect Day rewards? Can it hit a cash reward? Is the claim logged as "used by punishment"? A "Punishments are coming soon" announcement card is already in the site (`#pn-w`); nothing else is built.
- **55. Aftercare reward.** When a punishment is completed, as **aftercare she gets a random 0 to 100 points.** The chance is **weighted toward 0**, but **100 is possible.** The owner has not given the odds. **ASK** to approve a table. Example for him to react to (not final): 0 pts about 40%, 10 pts 25%, 25 pts 20%, 50 pts 10%, 75 pts 4%, 100 pts 1%. Compute the result on one device and sync it so both see the same number.

### 12.9 Games and learning (requests 56 and 57)

- **56. Point lottery.** She **enters for 10 points** and plays a **game** that pays **0 to 100 points.** The odds are **even worse than aftercare** (55), but **100 is possible.** This fits the games plan (Section 6, B2.3 prize wheel and prize table). **ASK:** which kind of game (wheel, scratch card, number pick)? How many plays per day? Approve the odds table. Example for him to react to (not final): 0 pts 55%, 5 pts 20%, 10 pts 12%, 25 pts 8%, 50 pts 4%, 75 pts 0.8%, 100 pts 0.2%. Warning: with these example odds the average is lower than 10 points, so the lottery loses points on average, which is what he asked for.
- **57. Learn something.** An **in-site module** where she **learns what daddy decides**, and gets **10 extra points** for it. **ASK:** how does daddy write the lesson (a text box in his tools?), one per day or whenever he wants, does she have to prove she learned (a short question or a tap to confirm), and are the 10 points once per lesson?

### 12.10 Suggested build order (for the owner to approve, do not start without him)

1. **37** Eat screen bug (blocks 24 and 41).
2. **39** Admin confirm (safety) and **52** Movie night to 6 points (tiny data edit).
3. **41** Food-logging penalty and its warning, then **40** movie sorting.
4. Rewards group: **48, 49, 50, 51, 58, 53**, and **47** display, with the claim screen **45**.
5. Tasks group: **42** secret tasks, **43** remove a task.
6. Punishments **54** with aftercare **55**, then the lottery **56** and **57** Learn something.
7. Looks last: **44** theme voting, **46** poop animation, **38** desktop resize.

### 12.11 Rules that still apply to everything above

- **Announce each finished item** with the one-time update popup and a NEW badge (Section 9).
- **Never publish anything**; show examples as a .html file in chat.
- Owner is on a phone, wants short plain steps, and wants whole finished files, not patches.
- Do not rename any `daddys-list*` storage keys. New shared data (votes, secret tasks, punishments, lottery results, lessons) needs its own `daddys-list-...` key so the sync carries it.
- Nothing is "done" until the owner has seen a screenshot.

---

## 13. REDESIGN FROM THE GROUND UP (owner, October 13, 2026): NOT BUILT, PLANNING ONLY

**No code for this section. It replaces the idea of "more themes." Read Section 12.6 (theme voting) and Section 5 Batch 8 (B8.1 themes, B8.2 redesign) with it; this section wins where they disagree.**

### 13.1 What the owner said (cleaned up)

- **59. She thinks the Minecraft theme is bad.** Rethink it completely. Make it about **10x better and authentic** (it should feel like the real thing, not a quick recolor).
- **60. This is NOT another theme.** It is a **complete site redesign from the ground up**, with new **layouts** (how screens are arranged), not only new colors and fonts.
- **61. She wants more minimalism, especially in desktop mode.** (Less clutter, fewer boxes and effects, more space, calmer. Desktop first.)
- Request 20 ("Redesign") and request 14 (themes, light mode) from Section 4 are the same family; fold them into this.

### 13.2 What this means for the plan

- **A theme today = colors and a few overrides** (`HANDOFF.md` section 15). A redesign = new structure (layouts, spacing, which things show, how big, where they live). Do not build it as another `data-dl-theme` block.
- **Design before code.** Order for this project: (1) owner answers the questions in 13.5, (2) mockups as .html files sent in chat (NEVER publish, see the standing rule), (3) owner and she pick, (4) build, (5) screenshots on her real devices.
- **Why mockups first:** the owner was burned before by designs that looked "incoherent," and nothing in this project has been visually previewed until a mockup is shown. Keep changes consistent and ask for a screenshot after each screen.
- **Build timing:** Batch 8 says "look comes last so work is not redone." That still holds, but many new features in Section 12 add screens (claim screen, secret tasks, punishments, lottery, Learn something). **Recommendation:** design the new layout system BEFORE building those screens, so each new screen is built once, in the new look. Bug fixes and data edits (37, 39, 52) can go first.
- **Keep working:** the sync, every `daddys-list*` storage key, and the points math must not change. A redesign touches only look and layout.
- **Minimalism, concretely (for the owner to approve):** fewer simultaneous boxes and glows, no page-wide ripple by default (the NEW badge ripple is the owner's wish, keep it small), plain readable type, generous spacing, one accent color, motion only where it means something (a reward claim, a task done). Desktop: a calm centered layout with side-by-side panels instead of a stretched phone screen.

### 13.3 Layouts to design (add to Section 10's non-scrolling rules)

Design each for **phone portrait** and **desktop**, and keep tap targets big (she likes the big boxes and ease of use, request 27):

1. **Main day screen** (the 6-row schedule and vitals).
2. **Hub** (Total Points: rewards, movies, tools; Section 10.3).
3. **Eat** (type food, food log, the 3-items-a-day warning).
4. **Rewards and the claim screen** (request 45).
5. **Tasks**, including secret tasks and removing a task.
6. **Movies** (sorting by rating and DC or Marvel).
7. **History** and week summaries.
8. **Punishments, aftercare, lottery, Learn something** (requests 54 to 57).
9. **Daddy tools / admin** (calm, with confirmations, request 39).
10. **Desktop mode**: side-by-side panels and resizable windows (request 38 belongs here).

### 13.4 The Minecraft look, redone (only if she still wants a Minecraft style)

- **Today:** a theme pack (colors plus the Pixelify Sans font) added in `HANDOFF.md` section 15; the pixel font was never seen rendered.
- **What "authentic" probably means (ASK to confirm):** real blocky pixel look, inventory-slot style panels, hotbar-style buttons, game-style text and sound, pixel icons, XP-bar style progress. Avoid copying protected game art or logos; build original pixel-style art that evokes it.
- **ASK first:** does she want the Minecraft style kept at all (redone), replaced by a different style, or dropped for the minimal look? (Recommended: make minimal the new default and offer one polished optional style on top of it.)

### 13.5 Questions for the owner and her (ask one at a time, short)

1. Keep a Minecraft style (redone), or drop it?
2. What does she dislike most about it (colors, font, too busy, hard to read, babyish)? A screenshot of what she likes elsewhere helps.
3. Name 1 to 3 apps or sites whose look she likes (to copy the feel, not the content).
4. Minimal means: light, dark, or both? One accent color or a few? Which color?
5. Desktop: what does she use (laptop width), and what should desktop show that the phone does not?
6. Does the redesign replace the Barbie theme and the original look, or do those stay as options? (The owner's request 44 allows only 3 themes at once.)
7. Which old screen should be designed first? Suggested: the main day screen, then Eat.
8. Who decides the final look: her, him, or both vote (request 44)?

### 13.6 Rules for whoever builds it

- Show mockups as .html files in chat. NEVER publish.
- Announce with the one-time update popup (Section 9).
- Phone-first checks at 390 x 844 and desktop checks at 1280 x 800, ask for screenshots on her real devices.
- Do not rename storage keys, do not change point rules, do not break sync.


---

## 14. SESSION OF OCT 13, 2026 (part 2): APPROVALS + "+N POINTS" ANIMATION (BUILT, NOT TESTED)

Full details, keys, search words, test checklist and open questions: **`SESSION-LOG-OCT-13-2026-APPROVALS-AND-POINTS-ANIMATION.md`**.

Built: (1) Perfect Day needs Daddy's approval. (2) Every reward claim by her is a request that Daddy approves (points are spent only on approval); same for the Halo game (+100 only after approval). (3) Gold "N waiting for you" pill on Daddy's device. (4) Her celebrations (GAME BEATEN, APPROVED!, Double picker) now play when Daddy approves. (5) Flat green themed "+N points" animation that floats up, shrinks and fades; plays whenever the total goes up.

Rules added from this session: keep `daddys-list-requests` as its own synced key (merge safety); only Daddy's device writes points for rewards and games; keep `NOAPPR` empty unless the owner names exceptions; ask the owner for a screenshot or video of the animation in every theme.

Open for the owner: which rewards (if any) skip approval; should Daddy's own claims need approval; push notifications for Daddy when she asks.
