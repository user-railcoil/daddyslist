# HANDOFF: "Daddy's List" (daddyslist.netlify.app)

> **CURRENT ADDRESS (owner, Oct 13, 2026, CORRECTED): the live site is https://daddyslist.netlify.app** (spelled **daddyslist**, with a Y, NOT daddieslist). Earlier notes said daddieslist; that was wrong and every link in these notes now says daddyslist. Only the site address was changed: the GitHub repo name `user-railcoil/daddieslist` and the Netlify project name are written as before and were NOT re-checked, so if an upload link 404s, ask the owner for the real repo name. Always use the CURRENT address in links you give the owner.

> **Oct 13, 2026 (END OF SESSION SUMMARY, read this first):** a full write-up of today's second batch (Perfect Day approval, Daddy approves ALL rewards and the Halo game, the "waiting for you" pill, celebrations on approval, the flat green themed "+N points" animation that floats up and shrinks) is in **`SESSION-LOG-OCT-13-2026-APPROVALS-AND-POINTS-ANIMATION.md`** with keys, search words, a test checklist and open questions. The short entries below are the same changes in the order they were made. Nothing from this batch has been run or visually checked.

> **Oct 13, 2026 (celebrations kept, +points v3):** the Halo GAME BEATEN party and a new APPROVED party now play on HER phone when Daddy approves (search `CELEBRATE WHEN DADDY APPROVES`; Double reward opens its picker then). The +N animation is now a FLAT green badge saying "+N point(s)" in the site's own greens, flying off in a random direction. Older notes: (v2: GREEN, BIGGER, THEMED): now a big green "+N" in the middle of the screen with a ring burst and flying bits; the green adapts to the theme (original / Barbie / Minecraft) and light or dark mode via the `PAL` table in the script (search `+POINTS ANIMATION`). Older description follows: a floating "+N" plays over TOTAL POINTS whenever the total goes up (N = amount gained; +1 per task, +100 for Halo). Watches `#pts-total` with a MutationObserver; silent for the first 3 s after load and when the tab is hidden; reduced-motion = fade only. Search `+POINTS ANIMATION`. Not run or visually checked; ask for a screenshot or video.

> **Oct 13, 2026 (Daddy approves rewards):** when she claims a reward (second tap) nothing is spent; a request goes into synced key `daddys-list-requests` and Daddy gets **Approve / Not yet** at the top of Rewards plus a gold "N waiting for you" pill (`#dl-wait`). Approve spends the points, writes the Claimed entry and runs the effects (Skip day, Reset, Double). Not yet shows her "Daddy said not yet" until she taps OK. While requests wait, her usable points drop by their cost. The Halo game works the same way (`daddys-list-games` entry with `pending:1`; points only after Approve). `NOAPPR` (array of reward ids) exempts rewards from approval; it is empty. Daddy's own device claims directly. Search `DADDY APPROVES REWARDS`. Not run or visually checked.

> **Oct 13, 2026 (Perfect Day needs Daddy's approval):** finishing every box now saves `d.unlocked.perfectPending` instead of unlocking. The tile says "waiting for Daddy"; Daddy gets **Approve Perfect Day** / **Not yet** (Approve saves `d.unlocked.perfect` with `approved:true`; Not yet saves `perfectDeclined`). She gets a popup when approved (flag `dl-perfect-appr-v1`). Search `PERFECT DAY NEEDS DADDY'S APPROVAL`. Already-unlocked perfect days stay unlocked. Not run or visually checked; ask for a screenshot.

> **Oct 13, 2026 (Double reward on ANY reward; punishments note + notice):** (1) **Double reward picker now lists EVERY reward**, used or not (owner correction); it no longer needs a reward to be claimed first. Flag `sk16` rewrites the Details text. If she doubles a reward she never claimed, she gets the 2 free uses and can still pay for the original later. (2) **Punishment idea (owner, not built):** some punishments could be a **time limit on a reward before it goes away**: when the time runs out the reward is **used as if she had bought it** (it is marked claimed, no points are spent or refunded, and it can only come back through Reset / Reverse / Double). Full note in `DADDYS-LIST-MASTER-PLAN.md` 12.8. (3) New one-time card **"Punishments are coming soon"** (`#pn-w`, flag `dl-punish-soon-v1`, replay `?punishnotice`, both devices, first person, waits for the Eat card). It only announces; no punishment code exists yet.

> **Oct 13, 2026 (Double reward flow + Games):** (1) **Double reward** (`r11`) is built: claiming it opens a picker (`#rw-dp`) of ALL rewards (corrected later the same day; itself allowed); pick one + **Double it!** adds 2 to `d.extras[id]`; such a reward shows gold "N free uses left" and a **Use free** button (two taps, 0 points, log line "Name (free)"). **Later** keeps `d.pendingDouble` and a gold banner reopens the picker. Search `DOUBLE REWARD FLOW`, flag `sk15`. DECISION TO CONFIRM WITH OWNER: the 2 extras are FREE uses (notes said "2 more"); for cash rewards that means free money, so he may want extras to be non-cash only or to cost points. (2) **GAMES**: a third button `GAMES` next to MOTION COMICS / MOTION PICTURES (`data-cat="2"`, intercepted in capture phase) opens layer `#gm-ov`. First game **Halo 5: Guardians, co-op, Legendary, with daddy = +100 points**, once. She taps **We beat it!** and confirms (`#gm-cf`, same idea as the movie confirm; the notes' open question "who confirms" was answered by copying the movie flow); points go through `daddys-list-points-adj`, state in synced key `daddys-list-games` = `{id:{at}}`; Daddy sees **Undo** (takes the points back). A party popup shows. Add games by adding a line to `GAMES` (search `GAMES (Oct 13`). No admin add-game form yet.

> **Oct 13, 2026 (reward categories + Perfect Day reward):** (1) Rewards now has 4 tabs: **Cash** ($20/$35/$100), **Daddy does** (Mommy?, Baby wendango, the game reward), **Perks** (Movie night, Skip a day; also the default for new rewards), **Power-ups** (Reverse, Reset, Double). Field `item.cat` = cash / daddy / perks / power, flag `sk14`, search `CATEGORIES + PERFECT DAY REWARD`; the Add form and Edit box have a category box; Up/Down move within a tab. (2) New reward **"Video game, your pick"** (`r13`, **12 points**, cat daddy, `lock:'perfect'`): Daddy plays a video game of HER choice, with her or by himself, until he beats it. It shows as a locked `???` tile (says it is a low-cost reward) until the **Perfect Day** achievement: every task box (`.chk-done`) checked on one day, or any saved history day with `pts>=ptsMax` (not skipped; this also counts old days). Saved forever in `d.unlocked.perfect` (synced), never re-locks. A one-time party popup `#rw-pd` shows per device (flag `dl-perfect-seen-v1`, replay `?perfectnotice`, never on Daddy's device). Daddy gets an **Unlock for her** button on the locked tile. Test script is not in the zip. Still not added: No AI coding for 3 days (3 pts, request 58).

> **Oct 13, 2026 (Mommy? time picker):** Mommy? (`r8`) is ONE reward with two time choices: **2 hours = 69 points, 3 hours = 169 points** (`item.opts`, flag `sk13`, search `MOMMY? TIME PICKER`). Two small buttons on the row pick the time; Claim uses that price and the Claimed log says e.g. "Mommy? (3 hours)". Any reward can use `opts`. The admin Edit box shows the prices as text for `opts` rewards (change them in code). Description and Details no longer say "3 hours" (they say "the whole time you pick"). Replaces the earlier "3 hours, 69 points" entries below.

> **Oct 13, 2026 (Details layer, Double reward, Baby wendango):** (1) the **Details** button now opens a popup LAYER (`#rw-dt`, closes on Close / outside tap / Escape) instead of expanding the row; search `DETAILS LAYER`. (2) Added **Double reward** (`r11`, 60 pts, "Get 2 more of any reward you pick. It works on itself too.", with a Details note) and **Baby wendango** (`r12`, 10 pts, "I show you proof that I changed your name in my phone to baby wendango."), flag `sk12`, search `DOUBLE REWARD + BABY WENDANGO`. Both honor system; the which-reward picker is NOT built (same as Reverse reward). Still not added from the notes: No AI coding for 3 days (3 pts, request 58).

> **Oct 13, 2026 (Details button, CORRECTS the Mommy? entry below):** any reward can have an optional `more` note shown only when its **Details** button is tapped (admin Edit box has a Details field, 600 characters; tagged `[S0L]`, search `MOMMY? DETAILS BUTTON`). Mommy? (`r8`) is back to its short description, and the kind-and-loving note (no butt stuff, at most ONE sexual thing in the 3 hours) is behind Details. Flag `sk11`.

> **Oct 13, 2026 (Mommy? details):** the `r8` description is now longer: it is mostly Daddy being kind and loving to her, NO butt stuff, and at most ONE sexual thing in the 3 hours. Flag `sk10`, search `MOMMY? DETAILS`; saved lists are updated once, only if the description was still the old text. Description boxes (Add and Edit) now allow 400 characters (was 140).

> **Oct 13, 2026 (Reset reward):** added **"Reset"** (item id `r10`, flag `sk9`, tagged `[S0L]`, search `RESET REWARD`), **175 points**, description "Brings back ALL of the rewards, so you can claim every one again." Claiming it marks every `claimed` entry (including its own) `reset:1`; those stay in the Claimed log but no longer count as bought, so every reward can be claimed again (Reset too). Added once to saved lists; if Daddy removes it in admin it stays removed.

> **STANDING RULE (owner, Oct 13, 2026): UPDATE CARDS ARE ALWAYS IN HIS VOICE.** Whenever you write or change any update card or popup text she reads, use "I", NEVER "we", and write it the way the owner talks as much as possible: first person, short, casual, plain words, a bit hopeful, no corporate tone, no "we're excited to". Example: "I tried to fix Eat", "hope it works", "tell me and I'll fix it again". Say only what is actually true (do not promise a fix, do not say a thing never happens if it sometimes does).

> **Oct 13, 2026 (Movie night price, request 52 DONE):** the Movie night reward (`r1`, "You pick tonight's movie") now costs **6 points** (was 50). Flag `sk8`, tagged `[S0L]`, search `MOVIE NIGHT PRICE`; changed once on saved lists only if still 50. The owner said to change ONLY this, so Double reward (49), Baby wendango (50) and No AI coding for 3 days (58) are still NOT added.

> **STANDING RULE (owner, Oct 13, 2026): FOR ANYTHING NEW, USE THE NOTES FOR COST AND WORDING.** Do NOT guess costs or text. Look it up in `DADDYS-LIST-MASTER-PLAN.md` first (rewards: Section 12.7, requests 48 to 52, 58, 62). Only ask him if the notes truly do not say. Still to add from the notes when he asks: 49 Double reward (60), 50 Baby wendango (10), 58 No AI coding for 3 days (3); request 52 changes Movie night to 6 points.

> **STANDING RULE (owner, Oct 13, 2026): EVERY REWARD GETS A DESCRIPTION.** Whenever you add a reward (in code or by any tool), ALWAYS include a short `desc`. The admin Add reward form now REQUIRES a description box (id `rw-new-desc`). Write descriptions in his voice, short and casual.

> **Oct 13, 2026 (reverse reward, CORRECTED):** added **"Reverse reward"** (item id `r9`, flag `sk6`, tagged `[S0L]`, search `REVERSE REWARD`), **50 points**, description "Brings back an already used reward." Cost and wording are straight from `DADDYS-LIST-MASTER-PLAN.md` request 48. (I first MISREAD "reverse reward" as the opposite-role reward and added a placeholder "Dom for 3 hours"; flag `sk7` corrects any list that got it.) The used-reward picker from request 48 is NOT built; it claims like an ordinary reward.

> **Oct 13, 2026 (reward descriptions):** any reward can now have an optional description (`item.desc`, shown small under the name, edited in the admin Edit box; tagged `[S0L]`, search `REWARD DESCRIPTIONS`). The Add reward form has no description box yet (edit after adding).

> **Oct 13, 2026 (sub reward, CORRECTED + card wording):** the owner's "sub for 3 hours" reward is **"Mommy?"** (item id `r8`, flag `sk4`, tagged `[S0L]`, search `SUB FOR 3 HOURS`), **69 points**, description "I'm a sub to you for 3 hours straight. I have to be a complete sub to Mommy, or your points are fully refunded." Cost and wording are from `DADDYS-LIST-MASTER-PLAN.md` request 51 (first person per the voice rule). The earlier placeholder ("Sub for 3 hours", 150) was wrong; flag `sk7` fixes lists that got it. The refund-if-not-a-complete-sub rule and the 9b safety limits are NOT built (honor system for now). Card `#ef-w` point 1 now says "tapping" (he writes "taps", NOT "ticking"; keep his own words when editing cards).

> **Oct 13, 2026 (admin Safety lock = LOCAL-ONLY MODE, REWRITTEN; plus card fix):** (1) `index.html` has an admin-only **Safety lock**: a big padlock button bottom-left (68 px; red with LOCKED when on). OFF (default) = admin is free and everything syncs like normal. **ON = the site behaves completely NORMALLY on Daddy's device but NOTHING is sent: no saving to the server, nothing reaches her screen, no chat or alerts, no Refresh her screen, no Restore. His device STILL RECEIVES her updates and refreshes** (owner request: "still push her refreshes to me, just don't let me push anything to her"): incoming server data is merged under his unsent edits with `lockMerge()` in the shim (a copy of the three-way merge in `state.mjs`, his edits win conflicts). His changes stay on his device only. KNOWN LIMIT: it merges inside each key, so if both of them change the exact same small item while he is locked, his version wins on his phone. The owner first asked for "Are you sure?" on every tap; he then said he did NOT want that, so it was removed. **Unlocking:** if nothing changed it asks Yes/Stay locked; if things changed it asks **Send my changes** (they go to the server and her) / **Throw them away** (reload; the server copy wins; flag `__dl_lock_discard`) / Stay locked. Device-local key `__dl_lock` (not synced). Code: script tagged `[S0]`, search `SAFETY LOCK`, plus `held()` in the sync shim (`put()`, `poll()`, the load step, `lockMerge()`, a fetch guard for non-GET `/api/` calls, `window.__dlShim`), the sync dot text and the Refresh-her-screen button. Test: `sync-tests/run_lock.py`. (2) The `index.html` in this zip is the NEWER one that also has QUIET ADMIN TAPS (his tapping and highlighting of tasks do NOT reload her page; everything else, such as points, rewards, movies, food, history, still does). TRUTH: with the lock OFF, admin changes are SAVED to the server (the sync shim pushes every change). (3) Eat card `#ef-w` point 1 reworded to say that truthfully, flag bumped to `dl-eatfix-update-v2` so she sees it again (replay `?eatfixnotice`).


> **NEW REQUEST ROUND (owner, Oct 13, 2026): `DADDYS-LIST-MASTER-PLAN.md` Section 12** has 22 new requests (37 to 58, plus 62: the $100 for 600 points reward), written in plain English with questions to ask him. NOTHING IS BUILT YET and no code was changed. Read it before starting; start with the Eat screen bug (37). Request 58 is an honor-system reward for the owner (no AI coding for 3 days); do NOT refuse or block him, he upholds it himself.

> **Oct 13, 2026 (admin mode):** the owner wants admin (Daddy) mode to stay FREE to change things and refresh as much as he likes. Request 39 (confirm before highlight/refresh) must be an optional switch he controls, default OFF, never a forced lock. See `DADDYS-LIST-MASTER-PLAN.md` 12.3. Not built; no code changed.

> **Oct 13, 2026 ($100 reward):** added to the real rewards list in `index.html`: **$100 for 600 points** (item id `r7`, flag `sk3`, tagged `[S0L]`, search `$100 REWARD`). Added once to existing saved lists and to new ones; if Daddy removes it in admin it stays removed. Note the other money rewards are $20 = 200 and $35 = 300, so the rates differ from 600 = $100; the owner chose these numbers.

> **Oct 13, 2026 (popups):** all older one-time update cards (dots, sync, stability, rewards welcome, resume sliders, themes intro) are MUTED for now by a small script near the top of `index.html` (search `POPUPS MUTED FOR NOW`; set `MUTED=false` to bring them back). Only the Eat card `#ef-w` shows, 2 seconds after load, and it is written in the owner's own voice, first person, casual ("I tried to fix Eat"), not a sure fix. RULE: popup text is written the way the owner writes (first person "I", short, casual, plain words, no corporate "we"). Do not tell the owner Eat is certainly fixed until he tests it on real devices.

> **Oct 13, 2026 (Eat follow-up):** (1) the same food can now be added more than once (the duplicate block in `addItem()` was removed; tagged `[S0]`). (2) One-time update card `#ef-w` "I tried to fix Eat" (flag `dl-eatfix-update-v1`, replay `?eatfixnotice`, both devices, waits for other popups). Added right after the `#rs-w` resume card.

> **REDESIGN PLAN (owner, Oct 13, 2026): `DADDYS-LIST-MASTER-PLAN.md` Section 13.** She dislikes the Minecraft theme; the owner wants a complete ground-up redesign with new layouts (not another theme), more minimal, especially on desktop. Planning only, nothing built. Show mockups as .html in chat, never publish.

> **FIX Oct 13, 2026 (Eat typing bug, request 37):** updates from the other device no longer reload the page while the Eat screen is open (see `DADDYS-LIST-MASTER-PLAN.md` 12.2, search `EAT TYPING FIX` in `index.html`). One edit inside the sync shim's `poll()`. Test: `sync-tests/run_eat.py`.

> **ADDED Oct 13, 2026 (all in `index.html`, tagged `[S0L]`):** (1) admin quick **+ / -** points buttons (step 1/5/10) at the top of Rewards; (2) admin **Up / Down / Edit / remove** on every reward; (3) admin **EXPORT** button (top of Motion Comics and in Rewards > Daddy's tools) that prints the Motion Comics list as plain text in the "COLLECTION 1" format with her current ratings, including the Iron Man argument note (`ar:1` flag on the Iron Man item in ITEMS). Function `mcText()`; popup `#mcx-ov`. The owner's text is hand-shortened to fit one line and MUST NOT be auto-corrected: per-item fields in ITEMS reproduce it exactly (`xt` = short tag like `M`/`S`, `tight` = tighter spacing on the Iron Man line), and the header/dash spacing is copied from his text. Verified byte-for-byte against his original text (Oct 13, 2026).

> **Motion Comics additions (Oct 13, 2026):** items with `ar:1` (Iron Man) show an ARGUMENT tag under the title (like STOPPED) plus a note in the open panel (worded "your rating may be affected", since she reads it; the admin export note says "her"). Everyone can set a **RESUME AT** time with three sliders (HR 0-6, MIN, SEC; no typing, owner request) plus SAVE/CLEAR in the open panel; the sliders show ONLY on To Watch items (owner request; unfinished items must be moved back first); on the Unfinished tab Daddy gets a one-tap **TO WATCH** button on each row (`.mc-q`, admin only). A one-time popup "Pick up where you left off" (`#rs-w`, flag `dl-resume-update-v1`, replay `?resumenotice`, her device only, waits for other popups) explains the sliders. Stored in seconds in `daddys-list-movies-at` (synced), shown as `RESUME AT` under the title and appended to the export line as `(AT h:mm:ss)` ONLY when set. Do NOT rename any `daddys-list*` storage keys when changing the site name; the sync depends on them.

> **STANDING RULE (owner, Oct 13, 2026): NEVER PUBLISH ANYTHING.** No artifacts, no hosted pages, no links. When the owner wants to see something (a demo, a mockup, an example), output the HTML directly as a file in the chat (send the .html file so it renders), exactly like the demo in section 16. Details in section 16.

> **UPDATE (Oct 10, 2026, night): section 14 at the bottom** covers the new sync light and daily server backups (`state.mjs` v5, shim additions). Read it with section 13.

> **UPDATE (Oct 10, 2026, evening, resync round 2, CONFIRMED WORKING; short story in `SYNC-NOTES.md`):** read section 13 at the very bottom. It covers: shim v3 (keep-alive only on page close, hung-request safety, 2.5 s checks), `state.mjs` v3/v4 (conditional write with retry, 503 when it cannot save, server-side clock correction), ONE announcement popup ("Resyncing update"), and the old Stability and Rewards-welcome popups kept as dormant templates. Sections 5a and 12 are still accurate except where section 13 says otherwise.


> **UPDATE (Oct 10, 2026, sync fix):** the sync was rebuilt so two devices can no longer overwrite each other. Read section 12 below before touching sync. Sections 5a and 7 were updated to match; older text about "whole snapshot, last write wins" is obsolete. Two files changed: `index.html` (sync shim) and `netlify/functions/state.mjs` (now merges).

> **UPDATE (step S0 done):** every feature in `index.html` now has a plain-English comment starting with `[S0]` (search for it). This file was written before Rewards, the movie list, brightness and points adjust existed, so see section 9 below and `DADDYS-LIST-MASTER-PLAN.md` for the full plan. The current `index.html` is about 350 KB, not 215 KB.

Read this fully before touching anything. It tells you what the project is, where every file lives, how it deploys, what has been built, and how to work with the owner.

## 1. What this is
A private, single-page daily-routine checklist web app for a couple. The owner ("Daddy", the admin) runs it for his partner ("Lovey", "her"). It shows a 6-row schedule grid (9am, 12pm, 3pm, 6pm, 9pm, 12am) with tappable tasks (done / in-progress), vitals in the header (weight, DAILY POINTS, TOTAL POINTS), a nutrition bar (fiber, added sugar, protein, calories, sodium), workout/eat/tea/groom/BP overlays, a history view, and a full-screen "zen" affirmation overlay with a three.js word-tunnel animation.

The ORIGINAL app is one big self-contained `index.html` (~215 KB, minified inline CSS and JS, no build step). It originally saved everything only in each browser's localStorage. Everything below was added on top of it.

## 2. Who you are working with (IMPORTANT)
- The owner uses ONLY a PHONE (iPhone Safari, plus Opera/Firefox for testing). No computer, no terminal, no git CLI.
- He is non-technical and gets frustrated by jargon. Give plain-language, ONE-STEP-AT-A-TIME instructions. Keep messages short. He has limited AI usage budget, so do not waste turns.
- He sends screenshots; use them. He cannot easily paste code into big editors, so prefer giving him complete finished files to upload rather than patches.
- He has been burned by designs that looked "incoherent". Keep visual changes conservative, consistent, and ask for a screenshot to verify. Nothing has ever been visually rendered/previewed by the assistant; all CSS was written blind from reading the code.

## 3. Hosting / deploy pipeline
- Live site: https://daddyslist.netlify.app  (Netlify project "daddieslist")
- Source: GitHub repo `user-railcoil/daddieslist`, branch `main`. Netlify is linked to it (continuous deployment). Every commit to `main` auto-deploys in about 1-2 minutes. Functions directory = `netlify/functions`.
- Netlify Blobs (built in, no setup) store all server data in a store named `daddys-list` (keys `state` and `chat`).
- Optional env var `SYNC_TOKEN` (NOT currently set): if set in Netlify, both functions require header `x-sync-token`; the page prompts once and stores it in localStorage `__dl_token`.

### How the owner updates files (phone only, via github.com in Safari)
- Replace/upload a top-level file (e.g. index.html): go to `https://github.com/user-railcoil/daddieslist/upload/main` (the `/main` is required), choose the file, tap green "Commit changes". Same filename overwrites.
- Edit a function file: `https://github.com/user-railcoil/daddieslist/edit/main/netlify/functions/chat.mjs` (or state.mjs): select all, delete, paste new code, "Commit changes...", "Commit changes".
- New file in a folder: `https://github.com/user-railcoil/daddieslist/new/main` and type the full path in the name box (e.g. `netlify/functions/foo.mjs`).
- After commit wait ~2 minutes; reload the site twice on every device (old cached copies are a recurring problem). Netlify "Deploys" page should show a new Published deploy.

## 4. Files (repo layout)
```
index.html                    the entire front end
netlify.toml                  [build] publish="." functions="netlify/functions"
package.json                  type:module, dependency @netlify/blobs ^8.1.0
netlify/functions/state.mjs   path /api/state  (sync of the app's localStorage; MERGES changes since Oct 10, 2026)
netlify/functions/chat.mjs    path /api/chat   (chat, alerts, edit/delete/clear)
README.md                     auto-created by GitHub, ignore
```
Deliver changed files to the owner as downloadable files. Only index.html and chat.mjs change often. Keep a zip of the whole project current.

## 5. index.html structure (order matters)
1. `<meta charset>` then IMMEDIATELY the **sync shim** `<script>` (must run before the app's own scripts).
2. Original app head/CSS/body/scripts (three.js via importmap/CDN, glitch title, grid, overlays).
3. A `<style id="dl-theme">` block (theme overrides, appended AFTER all app CSS so it wins).
4. A media-query block at the end of that style (portrait phone layout tweaks).
5. The **chat/alert widget** `<script>` just before `</body>`.
Edit with careful targeted string replacement (Python `str.replace` with `assert count==1`), then syntax-check every `<script>` with `node --check`. Never rewrite the original minified app wholesale.

### 5a. Sync shim (first script)
- Syncs every localStorage key starting with `daddys-list` (main ones: `daddys-list-state`, `-live`, `-history`, `-start-hour`, `-start-9am`) EXCEPT `-bright`, `-nightshift`, `-state-v1-backup` (device-specific).
- Non-synced helper keys: `__dl_token`, `__dl_ver`, `__dl_dirty`, `__dl_role`, `__dl_chat_seen`.
- On load: synchronous XHR GET `/api/state`; if server has data and the device isn't "dirty", overwrite local with server (server wins). If dirty (unsynced offline edits) or server empty, push local.
- Wraps `Storage.prototype.setItem/removeItem`; real changes push (PUT) after 300 ms. `norm()` strips the changing `savedAt` timestamp from the `-live` key so idle timestamp writes don't count as changes (that noise once caused devices to overwrite each other).
- Every 4 s while visible it checks the server version; if newer and the user has been idle >= 3 s (and chat/alert not open: `window.__dlChatOpen`) it reloads the page. Also flushes on `pagehide`/hidden.
- **Since Oct 10, 2026 the shim sends only what changed and the server merges it. See section 12.** Server record is still `{data:{key:value}, version}`.

### 5b. Chat + admin alerts (last script)
- Floating chat button bottom-right; full-screen chat panel. Polls `/api/chat` every 3 s while visible.
- Roles: EVERY device defaults to "lovey" (her). The owner opens `https://daddyslist.netlify.app/?daddy` once to become admin (stored in `__dl_role`); `?her` resets. Header shows "ADMIN . tap for her view". No real authentication (optional SYNC_TOKEN only), so keep the ?daddy link private.
- Admin extras: red **Alert** button, **Clear all**, per-message **Edit** (own messages only) and **Delete** (any message).
- Alert = message with `alert:true` from admin. On her phone it takes over the whole screen (pulsing red, huge text, beep via WebAudio after first touch, vibrate pattern on Android, flashing tab title, Notification if permitted and tab hidden) and repeats every 4 s until she taps "Got it", which POSTs `{ack:true}`; the admin sees "seen <time>" / "not seen yet". It reappears on every page open until acked.
- LIMITATION: alerts only fire while the site is open. True push when closed is NOT implemented (would need Web Push: service worker + VAPID keys + a subscription store + a sender function; iOS requires Add to Home Screen, 16.4+). Offer this as the next feature if asked.

### 5c. chat.mjs API (`/api/chat`)
GET -> `{messages:[...]}`. POST bodies:
- `{from, text, alert?}` new message (alert honored only if from==="daddy"); message = `{id, from:"daddy"|"lovey", text, alert?, ackAt?, edited?}`; ids are strictly increasing timestamps; capped at 200.
- `{ack:true}` marks all alerts seen. `{clear:true, from:"daddy"}` wipes chat. `{del:id, from:"daddy"}` deletes one. `{edit:id, text, from:"daddy"}` edits one of daddy's own.
Text is rendered with `textContent` (no HTML injection).

## 6. Theme / design (current state)
- Style source: the owner's file "Daddyslist_3_3.html" ("Suicide Squad 2016" graffiti/neon look): near-black purple base `#07020a`, **red `#ef4444`** (the owner explicitly wanted the earlier hot pink `#ff1464` replaced back with this red; it was mass-replaced, including rgba and light-theme variants), aqua `#00e8c8`, purple `#8b2be2`, lime `#c6ff00`. Includes grain + corner-gradient overlay on `.board::after`, gradient title text, Anton for times, Bungee for the big vital popup, lime glow on selected row. Light mode still exists via the `#theme-driver` checkbox.
- The whole look is driven by CSS custom properties (`--bg-t1`, `--prog-solid`, `--done-solid`, etc.) set in `<style id="dl-theme">`. Do NOT override `--bar-thickness`, `--time-bg`, `--header-height` globally; layout depends on them.
- All font sizes in the original CSS were scaled x1.3 for readability (owner request). The owner insists on UNIFORM text sizes: never shrink one item to make it fit; make boxes bigger instead.
- Portrait phone overrides (in the final @media block): taller header, header column split 33%/67%, weight box `flex:2`, nutrition bar rearranged into TWO rows (fib/sugar/protein over calories/sodium) so values fit, board rows use `minmax(0,1fr)`.
- Light mode contrast fixes: header numbers forced dark on white; over-limit/goal-unmet nutrition text recolored for contrast.
- Labels renamed: POINTS -> "DAILY POINTS", TOTAL -> "TOTAL POINTS" (wrap to two lines).
- Chat/alert widget colors follow the same palette.
- The zen/affirmation overlay + three.js animation is delayed until 3 minutes after page load (guard at the top of `const tA=()=>{...}`: `if(performance.now()<180000){...reschedule...}`).

## 7. Known issues / open items
- Owner reported the BOTTOM grid row looking shorter than the others. Code review shows rows are equal (`repeat(6,minmax(0,1fr))`); a likely cause (page taller than viewport after text enlargement) was addressed with `minmax(0,1fr)` but NOT confirmed. Ask for a screenshot before changing more.
- Nothing has been rendered/visually verified by an assistant. Ask the owner for screenshots after each visual change.
- ~~Server snapshot is whole-state last-write-wins~~ FIXED Oct 10, 2026 (section 12). Still true: other devices' changes arrive by a full page reload (not in place), and a device still running an OLD cached copy of the page can still overwrite (see 12.5).
- Old "in progress" marks from before the sync was introduced were lost when the first synced state replaced local data.
- No push notifications, no admin passcode, `SYNC_TOKEN` unset (anyone with the URL can read/write state and chat). Offer these as upgrades.
- Netlify's deploy-log viewer was temporarily broken once; unrelated to the site.

## 8. Working rules
- **NEVER PUBLISH ANYTHING (owner rule, Oct 13, 2026).** Do not publish artifacts or host pages anywhere. To show the owner something, send the HTML file directly in the chat (rendered inline), as in section 16.
- Keep every existing localStorage key name and the app's logic intact; the sync depends on the `daddys-list*` prefix.
- Keep the sync shim as the first script and the chat widget as the last script.
- After editing, run `node --check` on each `<script>` body and on `.mjs` files; deliver complete files; tell the owner exactly which GitHub URL to use for each file and to wait ~2 min and reload twice.
- When unsure about visuals, request a screenshot instead of guessing.
- **Non-scrolling screens (owner preference).** Every new screen must fit one phone screen; page it or split it into more buttons. Use tap targets that do nothing today (Daily Points, the five nutrition stats) before adding new buttons. Full layout plan in `DADDYS-LIST-MASTER-PLAN.md` Section 10.
- **Announce every major change on the site (standing rule, owner request).** After any major change (new feature, new screen, changed rule), ship two small things in the same upload: (1) a one-time "what's new" popup, and (2) a **NEW badge with the ripple animation** on the spot where the feature lives. Details in section 10.

## 9. Added since sections 1 to 8 were written (all commented in `index.html` with `[S0]`)
- **Rewards** (tap TOTAL POINTS): reward list, claiming (two taps within 4 s, subtracts points), "owed" rewards (due in 30 days, +10 points per full day late), 3-miss rule (every 3 missed tasks on finished days costs 1 point), welcome popup, NEW badge, ripple/warp effects. Key `daddys-list-rewards` (plus `daddys-list-rewards-start`). Claimed rewards stay in the list, so they can be claimed again.
- **Points adjust** (admin only): popup that adds or subtracts whole points, key `daddys-list-points-adj`. Read with `parseInt`, so half points need `parseFloat` everywhere.
- **Points script**: 1 point per task done. The max shown after TODAY is just the number of cells.
- **Motion Comics / movie watch list** (tea overlay) with letter-grade ratings (F D C B A S), the +3 "new movie with daddy" card, and **Point Bomb** (same list, full screen). Keys `daddys-list-movies`, `daddys-list-movies-ep`.
- **Brightness and night shift**: long-press the theme box (600 ms, pointer events) for two 6-level sliders. Keys `daddys-list-bright` and `daddys-list-nightshift` are device-specific and not synced. Reported as not working with a desktop mouse.
- **Confirm popups**: first tap on Poop (`dayplan`), Wake (`wake-meditate`), the two `brush-teeth-*` cells, and Sleep (marks IN PROGRESS) shows a popup. Tip popups for `free-r2` and `free-r4-b`. Note `brush-teeth-r4` is now the Escitalopram cell: ids are permanent labels.
- **Day start time**: holding a time slot changes when the day starts (key `daddys-list-start-hour`). Times are still 3 hours apart.
- **Hook for new features**: every cell is a form with `data-fid` = cell id and hidden checkboxes `.chk-done`, `.chk-prog`, `.chk-inactive`. Listen for the `change` event on `.chk-done` to react to a task being completed.
- **Not built yet**: see `DADDYS-LIST-MASTER-PLAN.md`.

## 10. Announcing changes: update popup + NEW badge with ripple (standing rule)

**Rule:** after every major change, push a short update notice to the site and put a NEW badge (with the ripple) wherever it helps people find the new thing. Do this in the same upload as the change, not as a later job. Skip it for tiny fixes.

**1. Update popup (one time per device).** Copy the pattern of `#fx-w` ("Stability update") or `#rw-w` ("Rewards are here"): a dark card, a red border, 2 to 4 short plain-English points, one button. Rules:
- The seen-flag is a per-device localStorage key that does NOT start with `daddys-list` (so it never syncs), named like `dl-<topic>-v1`. Bump the version number when the message changes.
- Add a `?replay` style URL switch (like `?fixednotice` and `?newbadge`) so the owner can see it again.
- Wait if another popup is open (see `busy()` in the fx script) so two popups never stack. Set `window.__dlChatOpen=true` while one is showing.
- Keep the wording short and non-technical. No jargon.

**2. NEW badge with ripple.** Built once for TOTAL POINTS (Rewards). Today it is hard-wired to that one box (`pts()`, `flag()`, `unflag()`, `ripple()` in the REWARDS script). To badge another feature, generalize those functions to take the target box. Rules for any badge:
- It disappears for good (per device flag, like `dl-rewards-opened-v1`) the first time the person opens or taps the thing it points to.
- Only ONE badge at a time gets the page-wide ripple. If several features are new, the others get just the badge and its ring, so waves never stack. Retire a badge after a couple of weeks even if it was never tapped.
- Never cover a label. Keep the label clear (see the `padding-right` rule in `#desktop-fit`).
- Respect `prefers-reduced-motion` (already handled), and keep the existing "replay" button for the owner.

**How the timing works (do not break this).** Everything runs on one clock so the badge and ripple stay in step:
- One badge beat = **3750 ms** (5 x the 750 ms tap grid `RIPPLE_GRID`). The swell peaks **750 ms** into the beat. Every second beat (**7500 ms**) is the big one: the badge swells more, a ring leaves it (`::before`, `rwEmit`), and the page ripple launches on that same frame.
- JS constants `BEAT`, `PEAK`, `RIP` in the REWARDS script must match the CSS numbers (`rwBadge`, `rwNtScale`, `rwEmit`, `rwRingS/O`, `rwPulse`, see the comment "BEAT CLOCK"). Change one, change all.
- `lockBadge()` pins every `rw*` animation to timeline zero (`startTime=0`) so a re-render can never shift the phase. New badge animations must be added to the `RWN` name list.
- `armRip()` aims for the next peak on the document timeline, fires on the exact frame, and takes the page photo 1.3 s early (`prewarm()`) so the wave never starts late.
- Pieces of a badge: `.vital-stat.rw-flag`, `::after` (the dot), `::before` (the ring), `.rw-nt` (the N-E-W letters), `#rw-ripple` (two page rings), `.rw-tap` (ground ring), and the water canvas `#wm-cv`. The water photo hides the badge and its ring, and the water has a soft hole over the badge so it stays crisp.
- Checked in headless Chromium (October 8, 2026): the ripple launched within one frame of the peak on the second and third cycles; the first cycle after page load can be late while the page is still loading. Still ask the owner for a phone screenshot or short video.

## 11. Layout plan summary (details in `DADDYS-LIST-MASTER-PLAN.md` Section 10)
- Leave the 12-box main screen alone. TOTAL POINTS opens a hub of big non-scrolling tiles: Rewards, Movies, Video games, Play, Earn more, Week and History, Look and feel, and (admin only) Daddy tools.
- DAILY POINTS and the nutrition bar have no tap action today; plan is a Today screen and a Food screen.
- Movies move into the hub. Point Bomb is THREE cells (`weigh-self`, `groom2-groom`, `groom3-groom`, all `is-tea is-pbomb`) sharing the movie overlay (`pbSync()`); they are to be replaced (recommended: a daily "Together time" box). `weigh-self` also drives the weigh-self number picker, so check it first.
- New request: rewards for finishing video games with daddy (Halo 5 first); plan is a library like the movie list under key `daddys-list-vgames`.
- A slide-down banner over the nutrition bar shows temporary things (double points, timed request, Owed countdown) without resizing the grid.
- Build order: Batch H (the homes) right after S0, then the feature batches, then themes and redesign last.
- The sync can be tested without a phone: see 12.6 (fake two-device test, no Netlify needed).
- The assistant can screenshot the page in headless Chromium (Playwright; path `/opt/pw-browsers/chromium-1194/chrome-linux/chrome` in the October 8, 2026 sandbox) at phone and laptop sizes. Still ask for a real phone screenshot.

## 12. SYNC (the owner's biggest problem). Rebuilt October 10, 2026

### 12.1 What was wrong (found by running two simulated devices, a phone-size and a laptop-size window, against a copy of the server)
1. **Whole-snapshot overwrite.** Every save sent the device's entire copy of the data and the last device to save won. A laptop that had not yet reloaded (it only learns about the phone's changes on a reload, checked every 4 s and only when idle) would send its OLD copy plus its one new tick, and the phone's newer ticks vanished. Reproduced exactly: phone ticks A, laptop ticks B a moment later, server ends up with only B. Two taps within a second of each other lost one of them too.
2. **Why it hit the laptop hardest.** A laptop tab tends to sit open for hours, often in the background, where browsers slow its timers, so it is the device most likely to be behind. Mouse-wheel scrolling was also not counted as activity by the idle check. (This explanation fits the evidence but was not observed on her real laptop.) A device that is behind is exactly the one that overwrites.
3. **Updates blocked while any panel is open.** `window.__dlChatOpen` is one shared true/false flag written by five different scripts (chat, Rewards, Rewards welcome popup, update popup, points-adjust). While it is true, that device never checks for updates. Any popup left unanswered (for example the "Rewards are here" welcome on a new device, which fills the whole screen) silently stops that device syncing. Not a data bug by itself, but combined with #1 it made the overwrite far worse.
4. **A failed save was never retried** while the device was marked dirty (`__dl_dirty=1`), and a dirty device also never reloaded, so one failed save could freeze it.
5. **Possible (NOT confirmed): Netlify Blobs reads default to "eventual" consistency**, so a read from another region can return a copy up to about a minute old. Fix applied (strong consistency) but it could not be tested outside Netlify. See 12.5.
- **Owner report, Oct 10, 2026 (points adjust):** adding points as `?daddy` showed on the phone, then reverted on both devices. Reproduced with the old code (phone sets `daddys-list-points-adj`, a second device with a stale copy saves and overwrites it; the server never keeps it). With the new code the points reach the server and the other device and stay. Awaiting the owner's confirmation on real devices after deploy.
- Checked and NOT a problem (run with the ORIGINAL sync code, 1280 x 800, then resizing through 390, 700, 1280, 1920 wide): refreshing right after a tap keeps the data, and resizing writes nothing and loses nothing. The old "everything disappears on refresh in Chrome and Edge at laptop size" bug did not come back. The NEW code was then tested at 390 x 844 (phone) and 1280 x 800 (laptop) for taps, races, offline and idle (no saves, no reload loops).

### 12.2 What was changed
- **`state.mjs`** now does a three-way merge. A device sends `{patch:{key:{b:<value it started from>, v:<new value>}}}` (v null = deleted). The server keeps whatever the device did NOT change, applies what it DID change, and merges JSON-object keys (`daddys-list-state`, `-history`, `-live`, `-movies`, ...) one inner item at a time. So two devices ticking different tasks at the same time both keep their ticks, and an un-tick only removes that one tick.
  - If both devices changed the SAME item: a history or live snapshot with a later `savedAt` wins, a later calendar day wins, anything else goes to the device that is saving.
  - A plain number or text key (for example `daddys-list-points-adj`) that both changed: the saving device wins.
  - After writing, the server reads the data back and merges again if another save slipped in between (up to 3 tries). The version number always goes up.
  - The old `{data:{...}}` whole-snapshot PUT is still accepted for old cached copies of the page (last write wins, as before).
  - Reads use `consistency: "strong"`.
- **Sync shim in `index.html`** (still the FIRST script, lines 1 to 55): remembers the last copy it synced in a new device-only key `__dl_base`, sends only the changed keys, and when the server answers with data from another device it leaves its version number old so the next 4-second check reloads to show it. On load, a device with unsynced edits merges them in (needs `__dl_base`; a device without it just takes the server copy, once). A failed save is retried on the next check. Mouse wheel and mouse-down now count as activity. Checks also run when the window regains focus or the network comes back. A panel left open (`__dlChatOpen`) stops blocking updates after 2 minutes without activity.
- Keys that never sync are unchanged. New device-only key: `__dl_base` (copy of the last synced data; roughly the size of the synced data, well inside the browser limit).
- No update popup or NEW badge was added (this is an under-the-hood fix; the standing rule in section 10 allows skipping for tiny fixes). Add a short "sync fixed" popup only if the owner asks.

### 12.3 What is still not ideal (do these later, see B4.2 in the master plan)
- Other devices' changes still arrive by `location.reload()` after 3 s idle, not in place. The reload only happens when the server actually has something this device lacks.
- The app keeps its own in-memory copy of its state (`SS`) and rewrites the whole `daddys-list-state` on each change. The merge makes that safe, but it means a device must reload after a merge before it shows the other device's ticks.
- Two devices unticking and re-ticking the same cell at the same moment: the saving device wins. Acceptable at this size.
- Midnight: if a laptop tab slept through midnight, the app finishes the old day and resets the board when it wakes. The merge keeps the newer history entry (later `savedAt` wins). This path was NOT simulated; watch for it and test it (set the laptop clock a day ahead) before relying on it.

### 12.4 How the owner should test (phone plus her laptop, about 3 minutes)
1. Upload both files (see 12.7), wait 2 minutes, then reload the site TWICE on every device.
2. Phone: tick any task. Laptop: tick a DIFFERENT task right away (do not reload first).
3. Wait about 10 seconds. Both devices should show BOTH ticks.
4. Laptop: untick one. Phone should lose only that one tick.
5. Turn the laptop's wifi off, tick a task, turn wifi on. Within about 10 seconds the phone should show it.
If anything is lost, ask for a screenshot of both screens and the time, then check the Netlify function log for `state`.

### 12.5 Risks and unknowns (say these plainly to the owner)
- Tested only with a stand-in server that runs the real `state.mjs` merge code and an in-memory store, in headless Chromium at phone (390 x 844) and laptop (1280 x 800 and 1920 x 1080) sizes. NOT yet tested on real Netlify, her real laptop, or Safari.
- The `consistency: "strong"` option for Netlify Blobs was written from memory of the library docs (`@netlify/blobs` ^8) and could not be checked offline. If the Netlify deploy log or the function log shows an error about it, delete the two `consistency` options in `state.mjs` and redeploy; everything else still works.
- A device still showing an OLD cached copy of the page runs the old shim, which sends a whole snapshot and can still overwrite. Reload twice on every device, or open the site in a private window once. If sync problems return right after a deploy, suspect this first.
- Anyone with the URL can still read and write (`SYNC_TOKEN` unset).

### 12.6 How to re-run the simulated two-device test
Files are in `sync-tests.zip` (not part of the website, do NOT upload to GitHub). Needs Node 20+, Python Playwright, and Chromium. In the October 10, 2026 sandbox: `node server.mjs &` (fake Netlify with the real `state.mjs` copied to `state_fn.mjs`), then `python3 run7.py` (stale edit, simultaneous taps, un-tick) and `python3 run8.py` (idle stability, offline merge, closed laptop). `node merge_test.mjs` unit-tests the merge rules. The test pre-sets the popup flags `dl-rewards-welcome-v1`, `dl-stability-update-v3`, `dl-rewards-opened-v1` so popups do not block syncing. Copy the real `state.mjs` over `state_fn.mjs` first.

### 12.7 Deploy steps for the owner (phone, github.com)
1. `https://github.com/user-railcoil/daddieslist/upload/main` > choose the new `index.html` > Commit changes.
2. `https://github.com/user-railcoil/daddieslist/edit/main/netlify/functions/state.mjs` > select all, delete, paste the new `state.mjs` > Commit changes.
3. Wait about 2 minutes, then reload the site twice on every device (phone and laptop).


## 13. Resync round 2 (Oct 10, 2026, evening)

### 13.1 Changes in `index.html` (sync shim is now "v3")
- Saves use `keepalive` ONLY when the page is closing/hiding AND the body is under 60,000 characters. Before, every save used keepalive; browsers cap keepalive bodies at about 64 KB, and a save carries both the old and new copy of each changed key, so a growing `daddys-list-history` made saves fail silently forever.
- A hung request can no longer block saving: `busy` is force-cleared after 20 s.
- Update checks every 2.5 s (was 4 s); reload after 2 s idle (was 3 s). NOTE: this makes about 60 percent more `/api/state` calls. The old address ran out of hosting credits once, so consider slowing the check when a tab has been idle a long while (not done).
- Every save sends header `x-client-time` (device clock, ms) so the server can detect a wrong device clock.
- `sameData()` now ignores `savedAt` stamps in `daddys-list-history` (the server may shift them), so a clock-corrected save does not cause a pointless reload.
- Popups: removed the auto-showing Stability (`#fx-w`) and "Rewards are here" (`#rw-w`) notices and the earlier Syncing notice. They are DORMANT TEMPLATES now: `?fixednotice` shows Stability, `?rewardsnotice` shows Rewards-welcome. The one live announcement is `#sy-w` "Resyncing update" (flag `dl-sync-update-v3`, replay `?syncnotice`). It says "Daddy" and "Lovey" (she is Lovey, the owner is Daddy). Functional popups (task confirms, tips, points adjust, Rewards screen) were NOT touched.

### 13.2 Changes in `state.mjs`
- v3 (conditional write with etags) was REMOVED the same evening: the owner reported nothing syncing after deploy. It depended on a Netlify Blobs feature (`getWithMetadata` + `onlyIfMatch`) that could not be checked offline and may have made every save return 503. `state.mjs` is now "v4-safe": plain `store.get`, merge, `setJSON`, read back, re-merge (up to 10 tries, 503 only if it can never confirm). The tiny same-millisecond race from 12.5 remains. Two simulated browsers (phone + laptop size) against the real `state.mjs` and the real `index.html` synced correctly in both store styles in the sandbox, so the failure was most likely server-side on real Netlify. CONFIRMED by the owner on real phone and desktop after this change. If it ever fails again, get the Netlify Functions log for `state` (Netlify > Logs > Functions) before changing anything else.
- v4: clock correction. If a device clock differs from the server clock by more than 2 minutes, `savedAt` stamps on the items that device just changed are shifted into server time before merging. Time zones never matter (`savedAt` is `toISOString()`, UTC); only a genuinely wrong clock does. Tested with simulated clocks 1 hour and 1 day fast and 1 hour slow (fix on: correct winner; fix off: wrong winner).
- The old whole-snapshot `{data}` PUT is still accepted (last write wins) for old cached pages. Option: refuse it and force a reload.

### 13.3 Still open (tell the owner plainly)
- **Day rollover and time zones: FIXED Oct 10, 2026 (13.4).** Left here only for history: `todayKey()` used each device's local date, so Dallas (Central) and Sarnia (Eastern, one hour ahead) disagreed about the day for an hour every night; the synced `daddys-list-live` key then made the two devices reset the board back and forth (`LIVE.key !== todayKey()` on each).
- Two different web addresses (daddyslist vs daddieslist) are two separate sites with separate servers and storage; devices on different addresses never sync.
- Old cached pages (old shim) can still overwrite. Reload twice after every deploy.
- Hosting credits / request volume (see 13.1). No passcode (`SYNC_TOKEN` unset).
- Other devices' changes still arrive by reload, not in place. Midnight rollover on a sleeping laptop is still untested. Nothing tested on real Netlify, real Safari, or her real laptop.
- Phone-only deploy tip: to put `state.mjs` in place without pasting, open `https://github.com/user-railcoil/daddieslist/upload/main/netlify/functions`, choose the file, Commit changes. In the GitHub editor on iPhone, "Commit changes..." opens a box that can appear off screen; scroll up or down to find the green Commit button, and nothing happens if the text was not changed.

### 13.4 Shared day (Oct 10, 2026)
Owner's choice: use the zone that is ahead (Sarnia, Eastern) and roll the day over at 1:00 am Eastern instead of midnight (1 am Eastern is midnight in Dallas; both observe DST on the same dates, so this always holds).
- A new tiny `<script>` right after the sync shim defines `window.__dlDayKey()` and `window.__dlMsToRollover()` (constants `TZ='America/Toronto'`, `ROLL_HOUR=1`; change those two to change the rule). The key is the Eastern calendar date of (now minus 1 hour). Falls back to the device's own clock if `Intl` time zones fail.
- Used by `todayKey()` (app + history + live), `dayKey()` in the movies/points script, `dayKey()` in the Rewards script (only when called without an argument; calls with a date, like due dates, still use local time), and `armMidnight()` (now fires at the next 1:00 am Eastern).
- NOT changed: the schedule rows, the highlighted current row and the clock display still follow each device's LOCAL time; the day-start hour (`daddys-list-start-hour`) is still read in local time. If that causes confusion, make those use one zone too (ask for screenshots first).
- Tested the key at the boundaries (summer EDT and winter EST, new year); not tested on the real devices. Deploying between 12 am and 1 am Eastern can trigger one stray board reset on her device, so deploy at another time.
- Popup flag bumped to `dl-sync-update-v4` and a "One shared day" point added.


## 14. Sync light + daily backups (Oct 10, 2026, night)
Done: items 1 and 2 of the SYNC-NOTES list. Files changed: `index.html` and `netlify/functions/state.mjs` only.

### 14.1 Sync light (inside the sync shim, searchable as `SYNC LIGHT`)
- **ADMIN ONLY** (owner's request): visible only when `__dl_role=daddy`; hidden on her device and when switching to her view. Small dot fixed bottom-left (`#dl-sy`). Green "Synced N s ago"; amber = saving, connecting, or no check for 3+ min; red + "NOT SAVING" tag = a failed request has persisted 7 s+, the device is offline, or changes have been unsaved 20 s+.
- Driven by `good()` / `bad()` calls on every save and every check. A single failed request is ignored for 7 s so it does not flicker.
- Tap it for a panel: status, **Export backup** (downloads the server copy; if the server is unreachable it downloads this device's own copy), and admin only (`__dl_role=daddy`) a dated-backup picker with **Restore** (two taps within 4 s) and **Undo last restore**. An open panel pauses the auto-reload (same rule as other panels).
- Popup `#sy-w` is shown to admin only. Rewritten to "Sync light + backups", flag `dl-sync-update-v5`, replay `?syncnotice`. No NEW badge was added.

### 14.2 Server backups (`state.mjs` v5)
- First save of each day (1:00 am Eastern day rule) stores the data as it stood just BEFORE that save under `backup-YYYY-MM-DD`; the newest 14 are kept. Everything is inside try/catch, so a backup failure can never block saving. Uses only `get`, `setJSON`, `list`, `delete` (no conditional writes).
- `GET /api/state?backups=1`, `?backup=DATE`, `?export=1`; `PUT {restore:"DATE"|"before-restore"}` (the replaced data is kept as `before-restore`).
- Restore has no server-side admin check (only the optional `SYNC_TOKEN`); the panel just hides it from non-admin devices.

### 14.3 Tested (sandbox only, fake store running the real `state.mjs`)
`sync-tests/run.py` (two devices) still passes; `sync-tests/run_light.py`: green on load, red after a simulated outage and green again after it, queued change reached the server, export works (also with server down), 17 simulated days kept exactly 14 backups, restore and undo key work, non-admin does not see restore. NOT tested on real Netlify: `store.list()` and `store.delete()` on the real library. If backups never appear, check the Netlify function log for "backup step failed"; saving will still be fine.

### 14.4 Still open
Items 3 to 8 of SYNC-NOTES section 7 (refuse old pages, slower idle checks, safe conditional-write test, passcode, in-place updates, 1am rollover test).


## 15. UPDATE (Oct 10, 2026, night): THEME PACK (Barbie + Minecraft), themes popup, bigger nutrition bar
- **Where:** everything is appended at the very end of `index.html`, right before `</body>`: `<style id="theme-pack">`, `<style id="nutri-size">`, a Google Fonts link (Pixelify Sans), the popup `#th-w`, and one `<script>`. A tiny early `<script>` just before the viewport meta applies the saved theme before first paint. The picker markup (`#th-pick`) sits inside `#bright-ui`.
- **How a theme works:** attribute `html[data-dl-theme="barbie"|"minecraft"]` (none = original). Each theme has a dark block (`html[data-dl-theme=x]`) and a light block (`html[data-dl-theme=x] #theme-driver:checked~.board`) that override the same CSS variables as `<style id="dl-theme">`, plus a few overrides for hard-coded reds (row glow, popups, board corner glows). Saved per device in localStorage `dl-theme-pack` (NOT synced).
- **Picker:** long-press the dot box, third column (row in landscape) called Theme. Taps on it are stopped from reaching the panel's close handler.
- **Minecraft** is open to everyone. **Barbie is the mystery theme:** hidden as a locked ??? tile until BOTH synced keys exist: `daddys-list-theme-earned` (her device writes the day when `window.__ptsToday() >= window.__ptsMax`, checked every second, two checks in a row, never on a Daddy device) and `daddys-list-theme-approved` = `1` (Daddy's device, from the "Approval needed" popup or the yellow APPROVE chip). Daddy's device (`__dl_role=daddy`) can always preview it. `?resetbarbie` (Daddy only) locks it again. This is an honor-system lock like the rest of the app.
- **Popups (one `#th-w`, four kinds):** intro (flag `dl-themes-intro-v1`, replay `?themesnotice`, says Minecraft how-to, mystery theme rules and BETA), earn (her), ask (Daddy), open/unlocked (her). Flags start `dl-` so they never sync. Shown only when `window.__dlChatOpen` is not true (so it never stacks on the sync notice or Rewards) and sets that flag while open.
- **Nutrition bar (phone, portrait):** the old `text-shrink` rule (any number >= 100) is overridden in `#nutri-size`; font is `clamp(17px,4.7vw,23px)` and the bar row is slightly taller.
- **Not done:** the NEW badge with ripple from section 10 was not added for themes (the badge code is hard-wired to Total Points). Minecraft pixel font not seen rendered (sandbox had no internet). Real two-device sync of earn/approve not tested on Netlify, only simulated roles in one browser.


## 16. Demo copy with fake data + the NEVER PUBLISH rule (Oct 13, 2026)
- **Owner rule: never publish anything.** Show examples by outputting the HTML directly as a file in the chat (send the .html so he can view it on his phone). No artifacts, no links, no hosting.
- The current `index.html` in this zip is the version the owner approved on Oct 13 ("That's good"). It is newer than the one in the previous zip.
- `demo-tool/` (not part of the website, do NOT upload to GitHub) builds `daddieslist-demo.html`: a copy of `index.html` with the sync shim removed, storage kept in memory only, calls to `/api/` blocked, and 7 fake finished days seeded from a scenario. A purple DEMO button (bottom-left) switches scenarios and opens History, Total points (Rewards) or the main screen. Scenarios: 7 perfect days, mostly good, skipped days, rough week, strong start then stopped, nothing done. Rebuild: `python3 -I build.py ../index.html harness.js daddieslist-demo.html`.
- Checked in headless Chromium at 390 x 844 only (not Safari).
- **Findings from the demo (tell the owner if he asks about misses):**
  - A day is saved to History only if something was ticked or food was logged. A day she never opens has NO card and NO penalty (the 3-miss rule only reads saved days). A day with one tick counts the other 11 tasks as missed (-3 points). So one tick can cost more than not opening the app.
  - There is no streak counter in the app. "7 days straight" in the demo just means 7 full cards in a row.
  - Today's card always shows at the top of History as 0/12 until she ticks things; that is the real behaviour.
