# Questions for the owner (answer these before any more changes)

**Rule for now: light mode is left exactly as it is. Do not touch it until the owner says what to do.**
No code was changed in this round. Only this file was added.

## A. Light mode: what needs fixing? (reply with letters, e.g. "1b, 2a")

1. What is wrong with light mode?
   - a) Some text is hard to read (too faint or wrong color)
   - b) Colors look ugly or don't match the dark look
   - c) Something is broken (button, bar, popup not working in light)
   - d) It switches by itself or doesn't remember my choice
   - e) Other (describe)
2. Which screens look wrong? (main grid, header numbers, nutrition bar, Rewards, Movies, history, zen screen, overlays, chat) Send a screenshot of each if you can.
3. Which device(s)? (iPhone Safari, Opera, Firefox, her phone)
4. Should light mode keep the red / aqua / purple / lime neon look, or become a calmer, plain light look?
5. Should light mode stay a toggle on the theme box, or follow the phone's own setting?
6. Is this the only thing to fix right now, or are there other problems to list too?

## B. Notifications (see the answer below), what do you want?

1. Which things should buzz her phone? 
   - a) Your alerts / messages to her
   - b) Reminders for each time slot (9am, 12pm, 3pm, 6pm, 9pm, 12am)
   - c) Rewards or points news
   - d) Other
2. Does she have an iPhone or Android? What iOS version (Settings > General > About)?
3. Is she OK adding the app to her Home Screen (needed on iPhone)?
4. Should you also get a notification when she taps "Got it" or finishes a task?
5. OK to proceed with the push upgrade as the next feature? (yes / not yet)

---

# Can she get notifications from this web app? How do you send them to her phone like a real app?

**Short answer: yes, real push notifications are possible. Not built yet.**

**What works today:** your alerts take over her screen, beep and vibrate, but ONLY while the site is open on her phone. If the app is closed or the phone is locked, nothing arrives.

**What is needed for real push (arrives when the app is closed, like WhatsApp):**
1. **Add to Home Screen.** On iPhone, push only works if she opens the site in Safari, taps Share, then "Add to Home Screen", and opens it from that icon. Needs iOS 16.4 or newer. Android Chrome works without this step, though installing it is still better.
2. **A manifest file** (name, icon, "standalone" display) so the phone treats it as an app. Small new file.
3. **A service worker** (`sw.js`). A tiny script that wakes up when a push arrives and shows the notification, even if the app is closed.
4. **Her permission.** A button in the app ("Turn on notifications") that she taps once. iPhone only allows asking after a tap, never automatically.
5. **VAPID keys.** A free pair of keys that proves the messages come from your site. Generated once, stored as Netlify environment variables.
6. **A place to store her subscription.** When she allows notifications, her phone gives the site a private address. A new Netlify function saves it in Netlify Blobs (already used for your state).
7. **A sender function.** When you send an alert (or a schedule time hits), a Netlify function sends the push through Apple's / Google's push service using the `web-push` library.
8. **For time-slot reminders:** a Netlify **scheduled function** (cron) that fires at 9am, 12pm and so on, so it works when nobody has the app open.

**Cost:** free at this size (Netlify free tier, Apple and Google push are free).

**Limits to know:**
- Not identical to an App Store app. No badge count control beyond basics, and iOS can show a short delay.
- If she turns off notifications for the app in iPhone Settings, nothing can override that.
- A notification can wake her phone, but it is not a continuous 4-second repeating alarm like the in-app takeover. A push can be re-sent every few minutes until she taps "Got it".
- Only works over https (daddyslist.netlify.app already is).

**Plan if you say yes (one step at a time):**
1. Add manifest, icon, and `sw.js`, plus a "Turn on notifications" button for her.
2. Add subscribe and send functions and VAPID keys.
3. Wire your existing alert button to also send a push.
4. Add scheduled time-slot reminders (optional).
5. Test on her phone, with a "NEW" badge and update popup as your rules require.
