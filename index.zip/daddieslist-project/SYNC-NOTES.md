# SYNC NOTES: everything done to fix syncing (Oct 10, 2026)

Plain-language record for the owner (Daddy) and for any assistant who works on this next.
Also read HANDOFF.md sections 12 and 13. This file is the short story; those are the technical details.

## 1. The problem
Daddy (Dallas, iPhone) and Lovey (Sarnia, Ontario, laptop) share one checklist. Ticks, points and history kept vanishing or not appearing on the other device.

## 2. What was wrong (found by reading the code and running two simulated devices)
1. Every save sent the device's WHOLE copy, so a device that was a few seconds behind wiped what the other device had just saved.
2. A device with a panel or popup left open never checked for updates.
3. A failed save was never retried on a "dirty" device.
4. Saves used a browser mode ("keep-alive") capped at about 64 KB. Each save carries the old and new copy of whatever changed, and history grows daily, so saves would start failing silently once the data got big.
5. A device whose clock is wrong could win a "newer save wins" comparison it should have lost.
6. The two time zones disagreed about what day it was for one hour every night (Sarnia is one hour ahead of Dallas), so the synced board was reset back and forth.
7. Two saves landing at the same instant could still overwrite each other (small window; still possible).

## 3. What was changed (all done Oct 10, 2026)
| Area | Change |
| --- | --- |
| Server `state.mjs` | Merges changes item by item instead of replacing everything (v2). Reads strongly consistent copies. Reads back after writing and merges again if another save slipped in, up to 10 tries, 503 only if it can never confirm. Corrects a device's `savedAt` stamps when its clock is more than 2 minutes off the server clock (header `x-client-time`). |
| Page `index.html` sync shim (v3) | Sends only what changed. Keep-alive only when the page is closing and the save is small. A hung save is cleared after 20 s. Checks the server every 2.5 s, reloads after 2 s idle. Retries failed saves. Sends the device clock reading. |
| Shared day | `window.__dlDayKey()` makes both devices use Sarnia (Eastern) time and roll the day over at 1:00 am Eastern (= midnight in Dallas). Used by `todayKey()`, both `dayKey()` helpers and `armMidnight()`. Change `TZ` and `ROLL_HOUR` in the small script right after the sync shim to change the rule. |
| Popups | One live notice: "Resyncing update" (flag `dl-sync-update-v4`, replay `?syncnotice`). The old Stability and "Rewards are here" notices are kept in the file as dormant templates (`?fixednotice`, `?rewardsnotice`). Task confirms, tips, points adjust and the Rewards screen were not touched. |

## 4. What went wrong during the fix (so nobody repeats it)
A first version of `state.mjs` used Netlify Blobs "conditional writes" (`getWithMetadata` + `onlyIfMatch`) to make two simultaneous saves impossible to lose. That feature could not be checked offline. After it was deployed, NOTHING synced. The owner reported it, the conditional write was removed, and syncing worked again (confirmed by the owner on real devices, Oct 10, 2026). Lesson: do not ship a server feature that could not be tested against the real Netlify library. If conditional writes are wanted later, test them first with a separate throwaway function.

## 5. Current state (confirmed working by the owner on real devices)
- Phone and desktop sync again after the safe `state.mjs`.
- Tested in the sandbox: two simulated browsers syncing in both directions with no page errors; wrong clocks (1 hour fast, 1 day fast, 1 hour slow) pick the truly newer save; the shared day changes at exactly 1:00 am Eastern in summer, winter and New Year.

## 6. Known weak spots that remain
1. A very rare same-instant collision of two saves can still lose one (about 1 in 12 in an extreme test with 12 saves at once; far rarer in real use).
2. Old cached copies of the page (old sync code) can still overwrite with a whole snapshot. Reload twice after every deploy.
3. Other devices' changes arrive by a page reload, not in place.
4. Anyone with the link can read and change the data (no passcode). Keep the `?daddy` link private.
5. Update checks every 2.5 s make many requests. The old address once ran out of hosting credits.
6. Two web addresses (daddyslist vs daddieslist) are two separate sites with separate data. Devices on different addresses never sync.
7. The schedule rows and the highlighted current row still follow each device's own local clock. Only the day change is shared.
8. Not tested: the midnight rollover on a sleeping laptop, Safari on a real iPhone beyond what the owner reported, a Netlify outage.
9. If a phone's storage is full, or a browser clears site data (iPhone Safari can after about a week unused), that device falls back to the server copy.

## 7. Ideas to make failure much less likely (in suggested order)
1. **Sync status light.** A small dot: green "synced 12 s ago", red "not saving". Today failures are silent.
2. **Daily backups on the server.** Keep a dated copy of the state each day (last 14 days) so a bad merge can always be undone, plus an "export backup" button.
3. **Refuse old-format saves** on the server and tell old cached pages to reload.
4. **Slow the update check when a tab is idle** to save hosting credits.
5. **Safely test conditional writes** on real Netlify, then use them to close the rare same-instant collision.
6. **Passcode** (`SYNC_TOKEN`).
7. **Show other device's changes without a reload** (larger change inside the app; needs screenshots and care).
8. **Test the midnight rollover** with a clock set a day ahead.

## 8. How to deploy (phone only)
- `index.html`: `https://github.com/user-railcoil/daddieslist/upload/main` > choose file > Commit changes.
- `state.mjs` and `chat.mjs`: `https://github.com/user-railcoil/daddieslist/upload/main/netlify/functions` > choose file > Commit changes.
- Wait about 2 minutes, reload twice on every device. Do not deploy between 12 am and 1 am Eastern.
- Do NOT upload `sync-tests/`, `HANDOFF.md`, `SYNC-NOTES.md` or the other .md files; they are for reference only.


## 9. Added later the same night: items 1 and 2 are DONE
- **Sync light** (Daddy's admin mode only; Lovey never sees it): dot at bottom-left. Green = synced, orange = saving, red + "NOT SAVING" = saving has stopped. Tap it for details.
- **Daily backups**: the server keeps one dated copy per day for 14 days (made at the first save of each day). Tap the light > **Export backup** to download a copy. Daddy's phone also shows **Restore** (tap twice) and **Undo last restore**.
- Files changed: `index.html` and `state.mjs` (upload both; see section 8).
- Not yet proven on real Netlify: listing and deleting old backups. If it fails, saving still works; backups just would not be kept.
- Still to do: items 3 to 8 in section 7.
