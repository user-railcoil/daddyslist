DEMO TOOL (not part of the website; do NOT upload this folder to GitHub)
Builds a copy of index.html filled with FAKE data so the owner can see how History and Rewards look
(7 perfect days, some missed, skipped days, nothing done...). Sync is removed and storage is in memory only,
so the real site's data is never touched.

Rebuild after index.html changes:
  python3 -I build.py ../index.html harness.js daddieslist-demo.html
Then hand the owner the finished daddieslist-demo.html as a file (see HANDOFF.md section 16). NEVER publish it.
Edit the scenarios at the top of harness.js (SCEN). The demo opens in Daddy's admin view; remove the __dl_role line for her view.
