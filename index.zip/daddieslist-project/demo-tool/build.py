import sys, re
src, harness, out = sys.argv[1:4]
h = open(src, encoding='utf-8').read()
js = open(harness, encoding='utf-8').read()

# 1) remove the sync shim: first <script> in the file, up to its closing tag
start = h.index('<script>/* [S0] SYNC SHIM')
end = h.index('</script>', start) + len('</script>')
assert h.count('<script>/* [S0] SYNC SHIM') == 1
h = h[:start] + h[end:]

# 2) insert the harness right after the shared-day script (it defines __dlDayKey and uses no storage)
marker = '<script>/* [S0] SHARED DAY'
i = h.index(marker)
j = h.index('</script>', i) + len('</script>')
h = h[:j] + '<script>' + js + '</script>' + h[j:]
open(out, 'w', encoding='utf-8').write(h)
print('ok', len(h))
