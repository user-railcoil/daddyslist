/* DEMO HARNESS (not part of the real app). Replaces the sync shim.
   - Storage lives in memory only, so nothing is saved and the real site's data is never touched.
   - Calls to /api/ are blocked, so nothing can sync.
   - A scenario (picked from the DEMO button, bottom-left) seeds 7 fake finished days. */
(function(){
/* ---------- in-memory storage ---------- */
var data={};
var mem={getItem:function(k){return Object.prototype.hasOwnProperty.call(data,k)?data[k]:null},
setItem:function(k,v){data[k]=String(v)},removeItem:function(k){delete data[k]},
clear:function(){data={}},key:function(i){return Object.keys(data)[i]||null}};
Object.defineProperty(mem,'length',{get:function(){return Object.keys(data).length}});
try{Object.defineProperty(window,'localStorage',{configurable:true,get:function(){return mem}})}catch(e){}
/* ---------- block the network calls to the real server ---------- */
var _f=window.fetch;
window.fetch=function(u){var s=String(u&&u.url||u);if(s.indexOf('/api/')>-1)return Promise.reject(new Error('demo: network off'));return _f.apply(this,arguments)};
var _o=window.XMLHttpRequest&&XMLHttpRequest.prototype.open;
if(_o)XMLHttpRequest.prototype.open=function(m,u){if(String(u).indexOf('/api/')>-1)u='about:blank';return _o.apply(this,arguments)};

/* ---------- scenarios ---------- */
var N=12; /* tasks per day (the app shows x/12) */
/* each day, oldest first: [points, weight] ; null = the app was never opened that day (no card is saved) */
var SCEN={
 perfect:{name:'7 perfect days',sub:'Every task done, 7 days straight',
  days:[[12,150.0],[12,149.8],[12,149.5],[12,149.3],[12,149.0],[12,148.8],[12,148.5]]},
 mostly:{name:'Mostly good, a few misses',sub:'Small slips: 0, 1, 0, 2, 0, 3, 0 missed',
  days:[[12,150.0],[11,149.9],[12,149.6],[10,149.7],[12,149.4],[9,149.5],[12,149.1]]},
 gaps:{name:'Skipped days in between',sub:'Two days she never opened the app (no card at all)',
  days:[[12,150.0],[12,149.7],null,[7,149.9],null,[12,149.6],[10,149.4]]},
 rough:{name:'Rough week',sub:'Lots of misses, low points every day',
  days:[[5,150.0],[3,150.2],[6,150.1],[2,150.5],[4,150.4],[1,150.6],[3,150.6]]},
 downhill:{name:'Strong start, then stopped',sub:'4 great days, then fading to almost nothing',
  days:[[12,150.0],[12,149.6],[11,149.4],[12,149.1],[4,149.3],[1,149.5],[1,149.7]]},
 nothing:{name:'Nothing done at all',sub:'No ticks, no food, all 7 days. The app saves no cards.',
  days:[null,null,null,null,null,null,null]}
};
var KEY=(location.hash||'#perfect').slice(1).split('/');
var SC=SCEN[KEY[0]]?KEY[0]:'perfect', VIEW=KEY[1]||'history';

function dkey(){return window.__dlDayKey?window.__dlDayKey():new Date().toISOString().slice(0,10)}
function shift(key,n){var p=key.split('-').map(Number),d=new Date(Date.UTC(p[0],p[1]-1,p[2]+n));return d.getUTCFullYear()+'-'+String(d.getUTCMonth()+1).padStart(2,'0')+'-'+String(d.getUTCDate()).padStart(2,'0')}
function pair(cur,t,u){return{cur:String(Math.round(cur*10)/10),target:String(t),unit:u||''}}
/* food roughly follows how much she did: done days hit the goals, bad days don't */
function snap(pts,w,dayIdx){
 var f=pts/N, r=(dayIdx*37%11)/100; /* tiny deterministic wobble */
 var cal=pts?Math.round(1800*(0.55+0.43*f)*(1+r/3)):0;
 var pro=Math.round(75*(0.35+0.7*f)*(1+r));
 var fib=Math.round(25*(0.3+0.75*f));
 var sod=Math.round(2300*(0.6+0.35*f)*(1+r/2));
 var sug=Math.round(25*(1.3-0.75*f)*10)/10;
 var sav=new Date(Date.now()-(7-dayIdx)*864e5);
 return{weight:String(w.toFixed(1)).replace(/\.0$/,''),pts:pts,ptsMax:N,miss:N-pts,
  cal:pair(cal,1800,''),pro:pair(pro,75,'g'),fib:pair(fib,25,'g'),sod:pair(sod,2300,'mg'),sug:pair(sug,25,'g'),
  workout:pts>=6?'Workout':'--',savedAt:sav.toISOString()};
}
var today=dkey(),hist={},first=shift(today,-7);
SCEN[SC].days.forEach(function(d,i){if(!d)return;hist[shift(today,i-7)]=snap(d[0],d[1],i)});
function put(k,v){data[k]=typeof v==='string'?v:JSON.stringify(v)}
put('daddys-list-history',hist);
put('daddys-list-state',{vw_0:150,w150:1});
put('daddys-list-rewards-start',first);   /* so the 3-miss rule counts all 7 demo days */
put('daddys-list-live',{key:today,snap:{}});
/* mark every one-time popup as already seen so none gets in the way */
['dl-rewards-welcome-v1','dl-rewards-opened-v1','dl-stability-update-v3','dl-sync-update-v5','dl-themes-intro-v1','dl-sync-update-v4'].forEach(function(k){data[k]='1'});
data['__dl_role']='daddy'; /* admin view (points adjust, etc.). Remove this line for her view. */
window.__demoSummary=function(){var a=0,m=0,days=0;Object.keys(hist).forEach(function(k){days++;a+=hist[k].pts;m+=hist[k].miss});return{days:days,pts:a,miss:m,pen:Math.floor(m/3)}};

/* ---------- demo panel ---------- */
function build(){
 var css=document.createElement('style');
 css.textContent='#dm-b{position:fixed;left:8px;bottom:8px;z-index:2147483000;font:700 12px/1 system-ui,sans-serif;letter-spacing:.08em;color:#fff;background:#6d28d9;border:2px solid #fff;border-radius:999px;padding:9px 13px;opacity:.92}'
 +'#dm-p{position:fixed;left:8px;bottom:50px;z-index:2147483000;width:min(330px,calc(100vw - 16px));max-height:calc(100vh - 70px);overflow:auto;background:#0d0613;color:#fff;border:2px solid #6d28d9;border-radius:14px;padding:12px;font:14px/1.3 system-ui,sans-serif;display:none;box-shadow:0 10px 40px #000}'
 +'#dm-p h4{margin:0 0 4px;font-size:12px;letter-spacing:.12em;color:#c4b5fd}#dm-p .sc{display:block;width:100%;text-align:left;margin:6px 0;padding:9px 10px;border-radius:10px;border:1.5px solid #3b2a55;background:#1a0f26;color:#fff;font:inherit}'
 +'#dm-p .sc b{display:block;font-size:14px}#dm-p .sc small{color:#b9a9d0;font-size:12px}#dm-p .sc.on{border-color:#a3e635;background:#26340f}'
 +'#dm-p .row{display:flex;gap:6px;margin-top:8px}#dm-p .row button{flex:1;padding:10px 4px;border-radius:10px;border:0;background:#ef4444;color:#fff;font:700 13px system-ui,sans-serif}'
 +'#dm-p .sum{margin:8px 0 2px;padding:8px 10px;background:#1a0f26;border-radius:10px;font-size:12.5px;color:#d8ccea}#dm-p .sum b{color:#fff}';
 document.head.appendChild(css);
 var b=document.createElement('button');b.id='dm-b';b.textContent='DEMO';document.body.appendChild(b);
 var p=document.createElement('div');p.id='dm-p';document.body.appendChild(p);
 var s=window.__demoSummary();
 var h='<h4>PICK A SCENARIO (fake data only)</h4>';
 Object.keys(SCEN).forEach(function(k){h+='<button class="sc'+(k===SC?' on':'')+'" data-k="'+k+'"><b>'+SCEN[k].name+'</b><small>'+SCEN[k].sub+'</small></button>'});
 h+='<div class="sum">Saved days: <b>'+s.days+'</b> &nbsp; Points earned: <b>'+s.pts+'</b><br>Missed tasks: <b>'+s.miss+'</b> &rarr; lose <b>'+s.pen+'</b> pt'+(s.pen===1?'':'s')+' (every 3 misses)<br>Net: <b>'+(s.pts-s.pen)+'</b></div>';
 h+='<div class="row"><button id="dm-h">History</button><button id="dm-r">Total points</button><button id="dm-m">Main screen</button></div><div class="sum" style="margin-top:8px">Tip: in History, drag up to scroll down through the 7 days.</div>';
 p.innerHTML=h;
 b.onclick=function(){p.style.display=p.style.display==='block'?'none':'block'};
 p.addEventListener('click',function(e){var t=e.target.closest('.sc');if(t){location.hash='#'+t.dataset.k+'/'+VIEW;location.reload()}});
 document.getElementById('dm-h').onclick=function(){p.style.display='none';VIEW='history';showHistory()};
 document.getElementById('dm-r').onclick=function(){p.style.display='none';VIEW='rewards';closeHistory();if(window.openRewards)window.openRewards()};
 document.getElementById('dm-m').onclick=function(){p.style.display='none';VIEW='main';location.hash='#'+SC+'/main';location.reload()};
}
function closeHistory(){var x=document.getElementById('history-exit-box');var v=document.getElementById('history-view');if(x&&v&&v.style.display==='flex')x.click()}
function showHistory(){
 var cell=document.querySelector('.is-sleep');if(!cell)return;
 var ci=cell.querySelector('.chk-inactive'),was=ci&&ci.checked;if(ci)ci.checked=true;
 var o={bubbles:true,cancelable:true,pointerId:1,clientX:5,clientY:5};
 cell.dispatchEvent(new PointerEvent('pointerdown',o));cell.dispatchEvent(new PointerEvent('pointerup',o));
 setTimeout(function(){if(ci)ci.checked=!!was},300);
}
function go(){build();setTimeout(function(){
 if(VIEW==='history')showHistory();else if(VIEW==='rewards'&&window.openRewards)window.openRewards();},1200)}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',go);else go();
document.title='Daddy’s List – DEMO';
})();
