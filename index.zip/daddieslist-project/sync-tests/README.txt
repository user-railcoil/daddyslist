SYNC TESTS - NOT PART OF THE WEBSITE. Do NOT upload this folder to GitHub.
Needs Node 20+, Python Playwright and Chromium. Run from inside this folder.

1) End-to-end, two simulated devices (phone size + laptop size) against the REAL state.mjs and index.html:
     MODE=plain node server.mjs &      (MODE=cond simulates a store with conditional writes)
     python3 run.py
   Expect: "B has it", "A has B points", "page errors: []", fails 0.
2) Wrong-device-clock cases:   node clock_test.mjs     (all four lines must say winner pts 1)
3) Shared-day boundaries:      node day_test.js        (all lines must say ok)
Note: clock_test.mjs writes a temporary st2.mjs next to itself; delete it afterwards.

4) Sync light, outage, export, 14-day pruning, restore:
     node server.mjs &      then   python3 run_light.py
   Expect: lines 1 to 8 as described in HANDOFF.md 14.3 and "page errors: []".
   (server.mjs now uses a keyed fake store; /ctl?down=1 simulates an outage, /ctl?shiftdays=N fakes the date.)

5) Eat screen hold (Oct 13, 2026):  node server.mjs &   then   python3 run_eat.py
   Expect: 1 reloads after about 3 s, 2 None (held), 3 reloads after about 1 s. (The test forces window.__dlChatOpen to false because an update popup is open on a fresh page.)

6) Safety lock = local-only mode (Oct 13, 2026):  node server.mjs &   then   python3 run_lock.py
   Expect: 3 server still 5; 3b her update ('from-her') arrives on his locked phone while his local 99 is kept and server K stays 5; 4 local 99 after reload; 5 blocked; 7 local 5 after Throw away; 9 server 42 after Send; 10 her device sees 42 and has no lock button; "errors []".
