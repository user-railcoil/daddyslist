import fs from 'fs';
let src=fs.readFileSync('../netlify/functions/state.mjs','utf8').replace('import { getStore } from "@netlify/blobs";','const getStore=globalThis.__gs;');
fs.writeFileSync('./st2.mjs',src);
let rec=null,et=0;
globalThis.__gs=()=>({
 async getWithMetadata(){return rec?{data:JSON.parse(rec),etag:String(et)}:null},
 async get(){return rec?JSON.parse(rec):null},
 async setJSON(k,v,o){if(o&&o.onlyIfMatch&&o.onlyIfMatch!==String(et))return{modified:false};if(o&&o.onlyIfNew&&rec)return{modified:false};rec=JSON.stringify(v);et++;return{modified:true}}});
const h=(await import('./st2.mjs')).default;
const K='daddys-list-history';
const put=(b,v,clockOffsetMs)=>h(new Request('http://x/api/state',{method:'PUT',headers:{'x-client-time':String(Date.now()+clockOffsetMs)},body:JSON.stringify({patch:{[K]:{b,v}}})}));
async function scenario(label,aOff,bOff){
  rec=null;et=0;
  const now=Date.now(), iso=t=>new Date(t).toISOString();
  const base=JSON.stringify({d:{pts:0,savedAt:iso(now-3600e3)}});
  await put(null,base,0);
  // A really edits at real time now-60s; B really edits at real time now-300s (older). B arrives later.
  const A=JSON.stringify({d:{pts:1,savedAt:iso(now-60e3+aOff)}});
  const B=JSON.stringify({d:{pts:2,savedAt:iso(now-300e3+bOff)}});
  await put(base,A,aOff); await put(base,B,bOff);
  const out=JSON.parse(JSON.parse(rec).data[K]).d;
  console.log(label,'-> winner pts',out.pts,'(want 1: A is truly newer)');
}
await scenario('both clocks right        ',0,0);
await scenario('B clock 1 hour FAST      ',0,3600e3);
await scenario('B clock 1 day fast       ',0,86400e3);
await scenario('A clock 1 hour SLOW      ',-3600e3,0);
