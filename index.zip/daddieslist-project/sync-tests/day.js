(function(){var TZ='America/Toronto',ROLL_HOUR=1,fmt=null;
try{fmt=new Intl.DateTimeFormat('en-CA',{timeZone:TZ,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});fmt.format(new Date())}catch(e){fmt=null}
function pad(n){return String(n).padStart(2,'0')}
function parts(t){var o={};fmt.formatToParts(new Date(t)).forEach(function(p){o[p.type]=p.value});return{y:+o.year,m:+o.month,d:+o.day,h:(+o.hour)%24,mi:+o.minute,s:+o.second}}
window.__dlDayKey=function(t){t=(t==null)?Date.now():t;if(!fmt){var d=new Date(t-ROLL_HOUR*36e5);return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}var p=parts(t-ROLL_HOUR*36e5);return p.y+'-'+pad(p.m)+'-'+pad(p.d)};
window.__dlMsToRollover=function(){var t=Date.now();if(!fmt){var n=new Date(t),m=new Date(n.getFullYear(),n.getMonth(),n.getDate()+1,ROLL_HOUR,0,1);return m-n}var p=parts(t-ROLL_HOUR*36e5);return(86400-(p.h*3600+p.mi*60+p.s))*1000+1000};
})();
