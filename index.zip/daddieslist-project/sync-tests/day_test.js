global.window=global;
require('./day.js');
const k=iso=>window.__dlDayKey(Date.parse(iso));
const cases=[
 ['2026-10-11T04:59:59Z','2026-10-10','just before 1:00am Sarnia (11:59pm Dallas)'],
 ['2026-10-11T05:00:00Z','2026-10-11','1:00am Sarnia = midnight Dallas'],
 ['2026-10-11T03:30:00Z','2026-10-10','11:30pm Dallas / 12:30am Sarnia: same day for both'],
 ['2026-10-10T18:00:00Z','2026-10-10','afternoon'],
 ['2026-12-01T05:59:59Z','2026-11-30','winter, just before 1am EST'],
 ['2026-12-01T06:00:00Z','2026-12-01','winter, 1am EST = midnight CST'],
 ['2027-01-01T05:59:00Z','2026-12-31','new year, before rollover'],
];
let bad=0;for(const [t,w,l] of cases){const g=k(t);if(g!==w)bad++;console.log(g===w?'ok ':'BAD',l,'->',g)}
// ms to rollover at 2026-10-11T04:59:30Z should be about 31s
const real=Date.now;Date.now=()=>Date.parse('2026-10-11T04:59:30Z');console.log('ms to rollover (expect ~31000):',window.__dlMsToRollover());Date.now=real;
process.exit(bad?1:0)
