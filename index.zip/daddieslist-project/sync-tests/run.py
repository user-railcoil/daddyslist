import sys,time,json
from playwright.sync_api import sync_playwright
FL="""try{localStorage.setItem('dl-rewards-welcome-v1','1');localStorage.setItem('dl-stability-update-v3','1');localStorage.setItem('dl-rewards-opened-v1','1');localStorage.setItem('dl-sync-update-v5','1')}catch(e){}"""
with sync_playwright() as p:
    b=p.chromium.launch()
    A=b.new_context(viewport={'width':390,'height':844}).new_page()
    B=b.new_context(viewport={'width':1280,'height':800}).new_page()
    errs=[]
    for pg,n in((A,'A'),(B,'B')):
        pg.on('pageerror',lambda e,n=n:errs.append((n,str(e)[:120])))
        pg.on('dialog',lambda d:d.dismiss())
    for pg in(A,B):
        pg.goto('http://localhost:8123/');pg.evaluate(FL);pg.reload();pg.wait_for_timeout(1500)
    # A saves something through the app's real storage path
    A.evaluate("localStorage.setItem('daddys-list-movies',JSON.stringify({m1:{n:'x'}}))")
    A.wait_for_timeout(2500)
    st=json.loads(__import__('urllib.request').request.urlopen('http://localhost:8123/stats').read())
    print('after A save:',st)
    # B should pick it up by itself (auto reload within a few secs)
    B.wait_for_timeout(7000)
    print('B has it:',B.evaluate("localStorage.getItem('daddys-list-movies')"))
    # B saves a different key, A should pick it up
    B.evaluate("localStorage.setItem('daddys-list-points-adj','5')")
    B.wait_for_timeout(8000)
    print('A has B points:',A.evaluate("localStorage.getItem('daddys-list-points-adj')"))
    print('A still has own movie:',A.evaluate("localStorage.getItem('daddys-list-movies')"))
    print('page errors:',errs[:4])
    print('stats:',json.loads(__import__('urllib.request').request.urlopen('http://localhost:8123/stats').read()))
    b.close()
