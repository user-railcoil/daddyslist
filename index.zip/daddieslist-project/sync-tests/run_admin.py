from playwright.sync_api import sync_playwright
FL="""try{localStorage.setItem('dl-rewards-welcome-v1','1');localStorage.setItem('dl-stability-update-v3','1');localStorage.setItem('dl-rewards-opened-v1','1')}catch(e){}"""
vis=lambda p:p.evaluate("(function(){var e=document.getElementById('dl-sy');return e?getComputedStyle(e).display:'missing'})()")
pop=lambda p:p.evaluate("document.getElementById('sy-w').classList.contains('show')")
with sync_playwright() as pw:
    b=pw.chromium.launch()
    for name,url in(('her (default)','/'),('daddy','/?daddy')):
        pg=b.new_context(viewport={'width':390,'height':844}).new_page();pg.on('dialog',lambda d:d.dismiss())
        pg.goto('http://localhost:8123'+url);pg.evaluate(FL);pg.reload();pg.wait_for_timeout(4500)
        print(name,'| light display:',vis(pg),'| popup showing:',pop(pg))
        if name=='daddy':
            pg.evaluate("localStorage.setItem('__dl_role','')");pg.wait_for_timeout(1500);print('daddy -> her view | light display:',vis(pg))
    b.close()
