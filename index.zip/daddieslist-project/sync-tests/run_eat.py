from playwright.sync_api import sync_playwright
FL="""try{localStorage.setItem('dl-rewards-welcome-v1','1');localStorage.setItem('dl-stability-update-v3','1');localStorage.setItem('dl-rewards-opened-v1','1');localStorage.setItem('dl-sync-update-v5','1')}catch(e){}"""
def wait_reload(A,n):
    for i in range(n):
        A.wait_for_timeout(1000)
        if A.evaluate("window.__marker") is None: return i+1
    return None
with sync_playwright() as pw:
    b=pw.chromium.launch()
    A=b.new_context(viewport={'width':390,'height':844}).new_page()
    B=b.new_context(viewport={'width':1280,'height':800}).new_page()
    for P in (A,B):
        P.goto('http://localhost:8123/');P.evaluate(FL);P.reload();P.wait_for_timeout(3000)
    A.wait_for_timeout(6000)
    A.evaluate("Object.defineProperty(window,'__dlChatOpen',{get:function(){return false},set:function(){},configurable:true})")
    # 1 control: no Eat open
    A.keyboard.press('Shift');A.evaluate("window.__marker=1")
    B.evaluate("localStorage.setItem('daddys-list-points-adj','21')")
    print('1 control (Eat closed) reloads after',wait_reload(A,15),'s')
    A.wait_for_timeout(4000)
    # 2 Eat open: must hold
    A.evaluate("Object.defineProperty(window,'__dlChatOpen',{get:function(){return false},set:function(){},configurable:true})")
    A.keyboard.press('Shift');A.evaluate("window.__marker=1;document.querySelector('.grid').classList.add('has-eat1')")
    B.evaluate("localStorage.setItem('daddys-list-points-adj','22')")
    print('2 Eat open reloads after',wait_reload(A,10),'(None = held, good)')
    # 3 close: must catch up
    A.evaluate("document.querySelector('.grid').classList.remove('has-eat1')")
    print('3 after closing Eat, reloads after',wait_reload(A,15),'s')
    b.close()
