import json,urllib.request as U
from playwright.sync_api import sync_playwright
FL="""try{localStorage.setItem('dl-rewards-welcome-v1','1');localStorage.setItem('dl-stability-update-v3','1');localStorage.setItem('dl-rewards-opened-v1','1');localStorage.setItem('dl-sync-update-v5','1')}catch(e){}"""
def ctl(q): U.urlopen('http://localhost:8123/ctl?'+q).read()
def stats(): return json.loads(U.urlopen('http://localhost:8123/stats').read())
cls=lambda p:p.evaluate("document.getElementById('dl-sy').className")
txt=lambda p:p.evaluate("document.querySelector('#dl-sy .t').textContent")
with sync_playwright() as pw:
    b=pw.chromium.launch()
    ctx=b.new_context(viewport={'width':390,'height':844},accept_downloads=True)
    A=ctx.new_page();errs=[];A.on('pageerror',lambda e:errs.append(str(e)[:120]));A.on('dialog',lambda d:d.dismiss())
    A.goto('http://localhost:8123/?daddy');A.evaluate(FL);A.reload();A.wait_for_timeout(4000)
    print('1 normal:',cls(A),'|',txt(A))
    A.screenshot(path='/tmp/light_green.png')
    A.click('#dl-sy .b');A.wait_for_timeout(800);print('panel open class:',cls(A))
    A.screenshot(path='/tmp/panel.png')
    A.click('#dl-sy .b')
    # outage
    ctl('down=1');A.evaluate("localStorage.setItem('daddys-list-points-adj','7')")
    A.wait_for_timeout(12000)
    print('2 outage:',cls(A),'|',txt(A))
    A.screenshot(path='/tmp/light_red.png')
    ctl('down=0');A.wait_for_timeout(6000)
    print('3 recovered:',cls(A),'|',txt(A),'| server has 7:',json.loads(U.urlopen('http://localhost:8123/api/state').read())['data'].get('daddys-list-points-adj'))
    # export
    A.click('#dl-sy .b')
    with A.expect_download() as d: A.click('#dl-sy .ex')
    dl=d.value;path=dl.path();j=json.load(open(path))
    print('4 export:',dl.suggested_filename,'keys',len(j['data']),'points-adj',j['data'].get('daddys-list-points-adj'))
    # export while server down -> local copy
    ctl('down=1')
    with A.expect_download() as d2: A.click('#dl-sy .ex')
    j2=json.load(open(d2.value.path()));print('5 export while down:',j2.get('source'),len(j2['data']))
    ctl('down=0')
    # backups across days + prune: shift the fake date forward 1 day at a time, saving each day
    for i in range(1,18):
        ctl('shiftdays=%d'%i);A.evaluate("localStorage.setItem('daddys-list-points-adj','%d')"%(100+i));A.wait_for_timeout(700)
    ks=sorted(k for k in stats()['keys'] if k.startswith('backup-'));print('6 backups kept:',len(ks),ks[0],'..',ks[-1])
    ctl('shiftdays=0')
    # restore as admin
    A.evaluate("localStorage.setItem('daddys-list-points-adj','999')");A.wait_for_timeout(1500)
    A.keyboard.press('Escape');A.wait_for_timeout(300)
    A.click('#dl-sy .b');A.wait_for_timeout(1200)
    opts=A.evaluate("[...document.querySelectorAll('#dl-sy .sel option')].map(o=>o.value)");print('7 options:',len(opts),opts[:2])
    A.select_option('#dl-sy .sel',opts[-1])
    A.click('#dl-sy .rs');print('   first tap:',A.evaluate("document.querySelector('#dl-sy .rs').textContent"))
    A.click('#dl-sy .rs');A.wait_for_timeout(3500)
    srv=json.loads(U.urlopen('http://localhost:8123/api/state').read())['data'].get('daddys-list-points-adj')
    print('   restored to',opts[-1],': server points-adj',srv,'| page',A.evaluate("localStorage.getItem('daddys-list-points-adj')"),'| undo key present','before-restore' in stats()['keys'])
    # non-admin should not see restore
    C=b.new_context(viewport={'width':390,'height':844}).new_page();C.goto('http://localhost:8123/');C.evaluate(FL);C.reload();C.wait_for_timeout(2500)
    print('8 her view restore block visible:',C.evaluate("getComputedStyle(document.querySelector('#dl-sy .a')).display"))
    print('page errors:',errs);b.close()
