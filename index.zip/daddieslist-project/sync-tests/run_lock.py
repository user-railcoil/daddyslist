import json,urllib.request
from playwright.sync_api import sync_playwright
FL="try{['dl-rewards-welcome-v1','dl-stability-update-v3','dl-rewards-opened-v1','dl-eatfix-update-v2','dl-sync-update-v5'].forEach(k=>localStorage.setItem(k,'1'))}catch(e){}"
def stats(): return json.load(urllib.request.urlopen('http://localhost:8123/stats'))['puts']
def srv(pg,k): return pg.evaluate("async k=>{var r=await fetch('/api/state?t='+Date.now());var j=await r.json();return j.data&&j.data[k]}",k)
K='daddys-list-points-adj'
with sync_playwright() as pw:
    b=pw.chromium.launch(); errs=[]
    D=b.new_context(viewport={'width':390,'height':844}).new_page(); D.on('pageerror',lambda e:errs.append(str(e)))
    D.goto('http://localhost:8123/?daddy'); D.evaluate(FL); D.reload(); D.wait_for_timeout(3000)
    D.evaluate("localStorage.setItem('%s','5')"%K); D.wait_for_timeout(1500)
    print('1 unlocked change reaches server:', srv(D,K), 'puts',stats())
    box=D.evaluate("(function(){var r=document.getElementById('dl-lk').getBoundingClientRect();return [r.width,r.height]})()"); print('  lock button size',box)
    D.click('#dl-lk'); D.wait_for_timeout(500); p0=stats()
    print('2 locked:', D.evaluate('__dlLock.on()'), D.inner_text('#dl-lk').replace('\n',' '))
    D.evaluate("localStorage.setItem('%s','99')"%K); D.wait_for_timeout(4500)
    print('3 locked change NOT on server (want 5):', srv(D,K), 'extra puts', stats()-p0)
    H0=b.new_context(viewport={'width':390,'height':844}).new_page(); H0.goto('http://localhost:8123/'); H0.evaluate(FL); H0.reload(); H0.wait_for_timeout(2500)
    H0.evaluate("localStorage.setItem('daddys-list-test-b','from-her')"); H0.wait_for_timeout(1500)
    D.wait_for_timeout(7000)
    print('3b locked, her update arrives on his phone:', D.evaluate("localStorage.getItem('daddys-list-test-b')"), '| his local edit kept:', D.evaluate("localStorage.getItem('%s')"%K), '| server K:', srv(D,K), '| still locked', D.evaluate('__dlLock.on()'))
    D.reload(); D.wait_for_timeout(3000)
    print('4 after reload still local 99:', D.evaluate("localStorage.getItem('%s')"%K), 'server', srv(D,K), 'extra puts', stats()-p0, 'locked', D.evaluate('__dlLock.on()'))
    r=D.evaluate("fetch('/api/chat',{method:'POST',body:'{}'}).then(()=>'sent',e=>'blocked')"); print('5 chat POST while locked:', r)
    print('  light text:', D.evaluate("document.querySelector('#dl-sy .t').textContent"))
    D.click('#dl-lk'); D.wait_for_timeout(300)
    print('6 unlock prompt:', D.inner_text('#dl-lkc .h'), '|', D.evaluate("[...document.querySelectorAll('#dl-lkc button')].map(b=>b.textContent)"))
    D.click('#dl-lkc button:has-text("Throw them away")'); D.wait_for_timeout(3500)
    print('7 after throw away: local', D.evaluate("localStorage.getItem('%s')"%K),'server',srv(D,K),'locked',D.evaluate('__dlLock.on()'),'extra puts',stats()-p0)
    D.click('#dl-lk'); D.wait_for_timeout(300); D.evaluate("localStorage.setItem('%s','42')"%K); D.wait_for_timeout(2000)
    print('8 locked again, server still', srv(D,K))
    D.click('#dl-lk'); D.wait_for_timeout(300); D.click('#dl-lkc button:has-text("Send my changes")'); D.wait_for_timeout(3500)
    print('9 after Send: server', srv(D,K),'locked',D.evaluate('__dlLock.on()'))
    H=b.new_context(viewport={'width':390,'height':844}).new_page(); H.goto('http://localhost:8123/'); H.wait_for_timeout(2500)
    print('10 her device sees', H.evaluate("localStorage.getItem('%s')"%K), 'lock button exists on her device', H.evaluate("!!document.getElementById('dl-lk')"))
    print('errors',errs); b.close()
