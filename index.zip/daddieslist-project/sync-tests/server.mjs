import http from 'http';import fs from 'fs';
// Fake Netlify Blobs (keyed, with list/delete) running the REAL state.mjs. Extra switches for tests:
//  GET /ctl?down=1 makes /api/state return 503, /ctl?down=0 restores it. /ctl?day=YYYY-MM-DD fakes the date (Date.now shift).
let src=fs.readFileSync(process.env.STATE||'../netlify/functions/state.mjs','utf8').replace('import { getStore } from "@netlify/blobs";','const getStore=globalThis.__gs;');
fs.writeFileSync('./state_fn.mjs',src);
const kv=new Map();
globalThis.__gs=()=>({
 async get(k){return kv.has(k)?JSON.parse(kv.get(k)):null},
 async setJSON(k,v){kv.set(k,JSON.stringify(v))},
 async delete(k){kv.delete(k)},
 async list(o){return{blobs:[...kv.keys()].filter(k=>k.startsWith((o&&o.prefix)||'')).map(key=>({key}))}}});
const h=(await import('./state_fn.mjs')).default;
const html=fs.readFileSync(process.env.INDEX||'../index.html');
let puts=0,fails=0,down=false;const realNow=Date.now;
http.createServer(async(q,r)=>{
 const u=new URL(q.url,'http://x');
 if(u.pathname==='/ctl'){if(u.searchParams.has('down'))down=u.searchParams.get('down')==='1';
  if(u.searchParams.has('shiftdays')){const d=Number(u.searchParams.get('shiftdays'))*86400000;Date.now=()=>realNow()+d}
  r.end('ok');return}
 if(u.pathname==='/api/state'){if(down){r.writeHead(503);r.end('down');return}
  const chunks=[];for await(const c of q)chunks.push(c);
  const req=new Request('http://x'+q.url,{method:q.method,headers:q.headers,body:['GET','HEAD'].includes(q.method)?undefined:Buffer.concat(chunks)});
  const res=await h(req);if(q.method==='PUT'){puts++;if(res.status!==200)fails++}
  const hd={'content-type':'application/json'};const cd=res.headers.get('content-disposition');if(cd)hd['content-disposition']=cd;
  r.writeHead(res.status,hd);r.end(await res.text());return}
 if(u.pathname==='/api/chat'){r.writeHead(200,{'content-type':'application/json'});r.end('{"messages":[]}');return}
 if(u.pathname==='/stats'){r.end(JSON.stringify({puts,fails,keys:[...kv.keys()]}));return}
 r.writeHead(200,{'content-type':'text/html'});r.end(html)}).listen(8123);
